# Notely Android — Phase A Engineering Report

Generated: 2026-11-21

## Scope and preservation

- Started from the supplied 53-file `agon-agent-android-release.zip` source archive.
- Kept the existing Expo/React Native application, navigation, screens, editor, assets, package identity, and persisted data keys.
- No app redesign, data-store reset, or feature removal was performed.
- Changes in this pass:
  - `src/lib/storage.ts`: added a persistent PIN-attempt guard stored in Android SecureStore. It records attempts and the 30-second lockout deadline, and fails closed if the guard cannot be read.
  - `src/screens/LockScreen.tsx`: loads the persistent guard before accepting PIN entry, checks it before verification, persists failed attempts, and clears the guard after successful PIN verification.
  - `src/screens/SettingsScreen.tsx`: resets the guard when a new PIN is successfully set or the lock is disabled.
  - `ANDROID_PRODUCTION_REVIEW.md`: updated with this pass's scope and validation limitations.

## Source inspection findings

### Positive findings
- Android application ID is configured as `com.arcadalabs.agonpreview`.
- EAS profiles exist for internal APK and production AAB.
- Existing data is loaded before seed data is considered; seed data is only written when no stored value exists.
- Storage includes a last-known-good JSON snapshot and preserves malformed primary JSON under a timestamped corrupt-data key before trying recovery.
- Android background handling attempts to flush pending notes.

### Release blockers / incomplete work
1. **PIN hashing is not complete.** Current new PIN representation is `pin:v2:<PIN>` in SecureStore. SecureStore encrypts/protects the value using the Android secure storage facility, but this is not a password hash or a slow password KDF. Do not describe it as hashed. A vetted KDF implementation and migration strategy are still required before claiming the PIN-hashing requirement is met.
2. **Persistent lockout has source changes but is not runtime-verified.** The five-failure/30-second rule must be tested on a physical Android device, including force-stop/restart and SecureStore failure paths.
3. **Auto-save is not yet release-grade.** Editor debounce is 900 ms and provider persistence is separately debounced. `saveJSON` returns a success boolean, but the app does not surface a durable Saved/Failed state to the editor. Background flush is best-effort and not a transactional guarantee.
4. **Storage writes are not atomic transactions.** The backup snapshot improves recovery but does not prove immunity to power loss, storage exhaustion, or concurrent write races.
5. **Backup/restore UX and cross-installation recovery are not implemented/verified in this pass.**
6. **Privacy policy, data deletion workflow, Play Store Data Safety declarations, and Play listing materials are not evidenced as complete.**
7. **Real-device, accessibility, performance, migration, export, and complete regression testing remain outstanding.**
8. **The permanent package ID must be confirmed by the app owner before first Play Store publication.**

## Validation evidence

| Check | Result | Evidence |
|---|---|---|
| ZIP inventory | PASS | 53 archive entries inspected |
| JSON syntax (`package.json`, `package-lock.json`, `app.json`, `eas.json`, `tsconfig.json`) | PASS | Node JSON.parse validation succeeded |
| `npm ci` | BLOCKED | Offline retry failed with `ENOTCACHED` for `@expo/vector-icons`; online attempt timed out |
| TypeScript syntax transpilation | PASS (syntax only) | Global TypeScript transpile check processed all 34 `.ts`/`.tsx` files with zero syntax diagnostics; this does not replace project typechecking |
| TypeScript typecheck (`tsc --noEmit`) | BLOCKED | `tsc --noEmit` could not resolve Expo/React dependencies or `expo/tsconfig.base` because dependencies were not installed; this is not a valid clean typecheck |
| Expo install check / Expo Doctor | NOT RUN | Requires installed dependencies and registry access |
| Android export / Gradle build | NOT RUN | Dependencies unavailable |
| EAS APK/AAB | NOT RUN | Requires dependencies and EAS build environment/authentication |
| PIN runtime tests | NOT RUN | No Android device/emulator available in this execution |
| Auto-save/data-loss tests | NOT RUN | No runtime test environment |
| Play Store submission checks | NOT RUN | Requires Play Console/app-owner declarations |

## Phase A status

**NOT COMPLETE — NOT PRODUCTION READY.**

This package is an engineering work-in-progress source update. The persistent lockout code is an improvement, not a substitute for device verification. Do not publish this build as a production release.

## Required next steps

1. Confirm the permanent Android package ID.
2. Implement and review a vetted slow PIN KDF with backward-compatible migration; keep secrets out of AsyncStorage.
3. Make save completion/failure observable and provide a durable pending-write/flush strategy.
4. Add automated tests for storage migration, corruption recovery, PIN guard, editor persistence, and export.
5. Install dependencies in a network-enabled environment; run `npm ci`, `npx expo install --check`, `npx expo-doctor`, `npx tsc --noEmit`, and `npx expo export --platform android`.
6. Build APK/AAB through EAS and verify on physical devices, including existing-install upgrade and force-stop/restart cases.
7. Complete privacy, data deletion, backup/restore, Play Console declarations, and release signing.
