import React, { useState } from 'react';
import { Text, View } from 'react-native';
import Svg, { Circle, Line, Path, Rect } from 'react-native-svg';
import { ChartBlock } from '../types';
import { smoothLine } from '../lib/draw';
import { useTheme } from '../store/ThemeContext';

export function ChartView({ block }: { block: ChartBlock }) {
  const { colors } = useTheme();
  const [w, setW] = useState(0);
  const data = block.data.filter(d => isFinite(d.value));

  return (
    <View onLayout={e => setW(e.nativeEvent.layout.width)} style={{ marginVertical: 10 }}>
      {!!block.title && (
        <Text style={{ fontSize: 14.5, fontWeight: '700', color: colors.text, marginBottom: 8 }}>{block.title}</Text>
      )}
      {w > 0 && data.length > 0 && (
        <ChartSvg block={block} width={w} />
      )}
      {data.length === 0 && (
        <Text style={{ color: colors.faint, fontStyle: 'italic', fontSize: 13 }}>No chart data</Text>
      )}
    </View>
  );
}

function ChartSvg({ block, width }: { block: ChartBlock; width: number }) {
  const { colors } = useTheme();
  const data = block.data;
  const H = 200;
  const padL = 8, padR = 8, padT = 22, padB = 26;

  if (block.chartType === 'pie') {
    const size = Math.min(width, 240);
    const total = data.reduce((s, d) => s + Math.max(0, d.value), 0) || 1;
    const cx = size / 2, cy = 100, r = 82;
    let angle = -Math.PI / 2;
    const slices = data.map((d, i) => {
      const frac = Math.max(0, d.value) / total;
      const a2 = angle + frac * Math.PI * 2;
      const large = a2 - angle > Math.PI ? 1 : 0;
      const x1 = cx + r * Math.cos(angle), y1 = cy + r * Math.sin(angle);
      const x2 = cx + r * Math.cos(a2), y2 = cy + r * Math.sin(a2);
      const path = frac > 0.999
        ? `M ${cx} ${cy - r} A ${r} ${r} 0 1 1 ${cx - 0.01} ${cy - r} Z M ${cx} ${cy} L ${cx} ${cy - r}`
        : `M ${cx} ${cy} L ${x1.toFixed(1)} ${y1.toFixed(1)} A ${r} ${r} 0 ${large} 1 ${x2.toFixed(1)} ${y2.toFixed(1)} Z`;
      angle = a2;
      return <Path key={i} d={path} fill={d.color} />;
    });
    return (
      <View>
        <Svg width={size} height={200}>
          {slices}
        </Svg>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 6 }}>
          {data.map((d, i) => (
            <View key={i} style={{ flexDirection: 'row', alignItems: 'center' }}>
              <View style={{ width: 10, height: 10, borderRadius: 3, backgroundColor: d.color, marginRight: 6 }} />
              <Text style={{ fontSize: 12, color: colors.subtext, fontWeight: '600' }}>{d.label} · {d.value}</Text>
            </View>
          ))}
        </View>
      </View>
    );
  }

  if (block.chartType === 'bar') {
    const max = Math.max(...data.map(d => d.value), 1);
    const n = data.length;
    const slot = (width - padL - padR) / n;
    const bw = Math.min(52, slot * 0.56);
    return (
      <Svg width={width} height={H}>
        <Line x1={padL} y1={H - padB} x2={width - padR} y2={H - padB} stroke={colors.border} strokeWidth={1.5} />
        {data.map((d, i) => {
          const bh = Math.max(3, ((H - padT - padB) * d.value) / max);
          const x = padL + slot * i + (slot - bw) / 2;
          const y = H - padB - bh;
          return <Rect key={i} x={x} y={y} width={bw} height={bh} rx={7} fill={d.color} />;
        })}
      </Svg>
    );
  }

  // line
  const max = Math.max(...data.map(d => d.value), 1);
  const n = data.length;
  const step = n > 1 ? (width - padL - padR) / (n - 1) : 0;
  const pts = data.map((d, i) => ({
    x: padL + step * i,
    y: H - padB - ((H - padT - padB) * d.value) / max,
  }));
  const line = smoothLine(pts);
  const area = pts.length > 1
    ? `${line} L ${pts[n - 1].x} ${H - padB} L ${pts[0].x} ${H - padB} Z`
    : '';
  return (
    <Svg width={width} height={H}>
      <Line x1={padL} y1={H - padB} x2={width - padR} y2={H - padB} stroke={colors.border} strokeWidth={1.5} />
      {!!area && <Path d={area} fill={colors.primary} opacity={0.09} />}
      {pts.length > 1 && <Path d={line} fill="none" stroke={colors.primary} strokeWidth={3} strokeLinecap="round" />}
      {pts.map((p, i) => (
        <Circle key={i} cx={p.x} cy={p.y} r={5} fill={data[i].color} stroke="#fff" strokeWidth={2} />
      ))}
    </Svg>
  );
}
