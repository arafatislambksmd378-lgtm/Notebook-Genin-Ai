import React from 'react';
import { Text, View } from 'react-native';
import { renderEquation } from '../lib/equation';
import { useTheme } from '../store/ThemeContext';

export function EquationView({ expr, size = 19 }: { expr: string; size?: number }) {
  const { colors } = useTheme();
  return (
    <View style={{
      marginVertical: 10, paddingVertical: 16, paddingHorizontal: 18,
      backgroundColor: colors.surface, borderRadius: 14, alignItems: 'center',
      borderWidth: 1, borderColor: colors.border,
    }}>
      <Text style={{
        fontSize: size, color: colors.text, fontStyle: 'italic',
        fontFamily: 'serif', textAlign: 'center', letterSpacing: 0.5,
      }}>
        {renderEquation(expr)}
      </Text>
    </View>
  );
}
