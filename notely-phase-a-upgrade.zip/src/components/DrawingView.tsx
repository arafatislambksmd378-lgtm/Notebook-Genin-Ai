import React, { useState } from 'react';
import { View } from 'react-native';
import Svg, { Path } from 'react-native-svg';
import { DrawingBlock } from '../types';
import { calligraphyPath, smoothLine } from '../lib/draw';

export function DrawingView({ block, width: fixedWidth }: { block: DrawingBlock; width?: number }) {
  const [measured, setMeasured] = useState(0);
  const w = fixedWidth || measured;
  const h = w * block.aspect;

  return (
    <View
      onLayout={e => setMeasured(e.nativeEvent.layout.width)}
      style={{ marginVertical: 10, borderRadius: 14, overflow: 'hidden' }}
    >
      {w > 0 && (
        <Svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
          {block.paths.map((p, i) => {
            const pts = p.points.map(q => ({ x: q.x * w, y: q.y * h }));
            const sw = Math.max(0.6, p.width * w);
            if (p.tool === 'calligraphy') {
              return <Path key={i} d={calligraphyPath(pts, sw)} fill={p.color} />;
            }
            return (
              <Path
                key={i}
                d={smoothLine(pts)}
                fill="none"
                stroke={p.color}
                strokeWidth={sw}
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeOpacity={p.tool === 'highlighter' ? 0.35 : 1}
              />
            );
          })}
        </Svg>
      )}
    </View>
  );
}
