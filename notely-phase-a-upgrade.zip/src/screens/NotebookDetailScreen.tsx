import React, { useMemo } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp } from '../store/AppContext';
import { useTheme } from '../store/ThemeContext';
import { RootStackParamList } from '../navigation';
import { NoteCard } from '../components/NoteCard';
import { NotebookIcon } from '../components/NotebookIcon';
import { EmptyState } from '../components/ui';
import { soft } from '../theme';
import { haptic } from '../lib/storage';

type Nav = NativeStackNavigationProp<RootStackParamList>;

export default function NotebookDetailScreen() {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const nav = useNavigation<Nav>();
  const route = useRoute<RouteProp<RootStackParamList, 'NotebookDetail'>>();
  const { notebooks, notesIn, createNote } = useApp();

  const notebook = notebooks.find(nb => nb.id === route.params.notebookId);
  const notes = useMemo(() => notesIn(route.params.notebookId), [notesIn, route.params.notebookId]);

  if (!notebook) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center' }}>
        <Text style={{ color: colors.subtext }}>Notebook not found</Text>
      </View>
    );
  }

  const newNote = () => {
    haptic('medium');
    const note = createNote(notebook.id);
    nav.navigate('Editor', { noteId: note.id });
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <FlatList
        data={notes}
        keyExtractor={n => n.id}
        numColumns={2}
        columnWrapperStyle={{ gap: 14 }}
        contentContainerStyle={{ padding: 20, paddingBottom: 120, paddingTop: insets.top + 8 }}
        ItemSeparatorComponent={() => <View style={{ height: 14 }} />}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={
          <View style={{ marginBottom: 20 }}>
            <Pressable onPress={() => nav.goBack()} hitSlop={8} style={[styles.backBtn, { backgroundColor: colors.surface }]}>
              <Ionicons name="chevron-back" size={20} color={colors.text} />
            </Pressable>
            <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 18 }}>
              <NotebookIcon icon={notebook.icon} color={notebook.color} size={56} />
              <View style={{ marginLeft: 14, flex: 1 }}>
                <Text style={{ fontSize: 25, fontWeight: '800', color: colors.text, letterSpacing: -0.5 }}>{notebook.name}</Text>
                <Text style={{ fontSize: 13, color: colors.faint, fontWeight: '600', marginTop: 2 }}>
                  {notes.length} {notes.length === 1 ? 'note' : 'notes'}
                </Text>
              </View>
            </View>
          </View>
        }
        renderItem={({ item }) => (
          <View style={{ flex: 1 }}>
            <NoteCard
              note={item}
              onPress={() => nav.navigate('Editor', { noteId: item.id })}
            />
          </View>
        )}
        ListEmptyComponent={
          <EmptyState
            icon="albums-outline"
            title="Empty notebook"
            message="This notebook is waiting for its first page."
            actionLabel="Write a note"
            onAction={newNote}
          />
        }
      />
      <Pressable
        onPress={newNote}
        style={[styles.fab, { bottom: insets.bottom + 24, backgroundColor: notebook.color, shadowColor: notebook.color }]}
      >
        <Ionicons name="add" size={28} color="#fff" />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  backBtn: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center' },
  fab: {
    position: 'absolute', right: 22,
    width: 60, height: 60, borderRadius: 21,
    alignItems: 'center', justifyContent: 'center',
    shadowOpacity: 0.4, shadowRadius: 14, shadowOffset: { width: 0, height: 8 }, elevation: 8,
  },
});
