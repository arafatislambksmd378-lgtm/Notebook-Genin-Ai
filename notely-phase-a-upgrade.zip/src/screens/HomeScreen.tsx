import React, { useMemo, useRef, useState } from 'react';
import {
  Animated, FlatList, Pressable, RefreshControl, StyleSheet,
  Text, TextInput, View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp } from '../store/AppContext';
import { useTheme } from '../store/ThemeContext';
import { RootStackParamList } from '../navigation';
import { NoteCard } from '../components/NoteCard';
import { NotebookIcon } from '../components/NotebookIcon';
import { EmptyState, SectionHeader, Sheet } from '../components/ui';
import { formatFullDate, greeting } from '../lib/utils';
import { ACCENTS, soft } from '../theme';
import { Note } from '../types';
import { haptic } from '../lib/storage';

type Nav = NativeStackNavigationProp<RootStackParamList>;

export default function HomeScreen() {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const nav = useNavigation<Nav>();
  const { notes, notebooks, settings, createNote, deleteNote, duplicateNote, togglePin, saveNote } = useApp();
  const [query, setQuery] = useState('');
  const [refreshing, setRefreshing] = useState(false);
  const [menuNote, setMenuNote] = useState<Note | null>(null);
  const fabScale = useRef(new Animated.Value(1)).current;

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const sorted = [...notes].sort((a, b) =>
      (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0) || b.updatedAt - a.updatedAt);
    if (!q) return sorted;
    return sorted.filter(n =>
      n.title.toLowerCase().includes(q) ||
      n.blocks.some(b => (b.type === 'text' && b.text.toLowerCase().includes(q)) ||
        (b.type === 'table' && b.rows.flat().join(' ').toLowerCase().includes(q)))
    );
  }, [notes, query]);

  const nbById = useMemo(() => new Map(notebooks.map(nb => [nb.id, nb])), [notebooks]);

  const newNote = () => {
    haptic('medium');
    const note = createNote();
    nav.navigate('Editor', { noteId: note.id });
  };

  const animateFab = (to: number) =>
    Animated.spring(fabScale, { toValue: to, useNativeDriver: true, speed: 40, bounciness: 8 }).start();

  const header = (
    <View>
      <View style={[styles.headerRow, { marginTop: insets.top + 8 }]}>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 13, color: colors.faint, fontWeight: '600' }}>{formatFullDate(Date.now())}</Text>
          <Text style={{ fontSize: 27, fontWeight: '800', color: colors.text, letterSpacing: -0.6, marginTop: 2 }}>
            {greeting()}{settings.userName ? `, ${settings.userName}` : ''}
          </Text>
        </View>
        <View style={[styles.avatar, { backgroundColor: colors.primary }]}>
          <Ionicons name="create" size={20} color="#fff" />
        </View>
      </View>

      <View style={[styles.searchBar, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Ionicons name="search" size={18} color={colors.faint} />
        <TextInput
          value={query}
          onChangeText={setQuery}
          placeholder="Search notes, tables, ideas..."
          placeholderTextColor={colors.faint}
          style={[styles.searchInput, { color: colors.text }]}
          returnKeyType="search"
          clearButtonMode="while-editing"
        />
        {!!query && (
          <Pressable onPress={() => setQuery('')} hitSlop={8}>
            <Ionicons name="close-circle" size={18} color={colors.faint} />
          </Pressable>
        )}
      </View>

      {!query && (
        <View>
          <SectionHeader title="Notebooks" />
          <FlatList
            horizontal
            data={notebooks}
            keyExtractor={nb => nb.id}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingRight: 20, gap: 12 }}
            renderItem={({ item: nb }) => {
              const count = notes.filter(n => n.notebookId === nb.id).length;
              return (
                <Pressable
                  onPress={() => nav.navigate('NotebookDetail', { notebookId: nb.id })}
                  style={[styles.nbCard, { backgroundColor: colors.card, borderColor: colors.border, shadowColor: colors.shadow }]}
                >
                  <NotebookIcon icon={nb.icon} color={nb.color} size={42} />
                  <Text numberOfLines={1} style={{ fontSize: 13.5, fontWeight: '700', color: colors.text, marginTop: 8 }}>{nb.name}</Text>
                  <Text style={{ fontSize: 11, color: colors.faint, fontWeight: '600', marginTop: 1 }}>
                    {count} {count === 1 ? 'note' : 'notes'}
                  </Text>
                </Pressable>
              );
            }}
          />
        </View>
      )}

      <SectionHeader title={query ? `Results (${filtered.length})` : 'Recent notes'} />
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <FlatList
        data={filtered}
        keyExtractor={n => n.id}
        numColumns={2}
        columnWrapperStyle={{ gap: 14 }}
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 120 }}
        ListHeaderComponent={header}
        ItemSeparatorComponent={() => <View style={{ height: 14 }} />}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => { setRefreshing(true); setTimeout(() => setRefreshing(false), 500); }}
            tintColor={colors.primary}
          />
        }
        renderItem={({ item }) => (
          <View style={{ flex: 1 }}>
            <NoteCard
              note={item}
              notebookName={nbById.get(item.notebookId)?.name}
              notebookColor={nbById.get(item.notebookId)?.color}
              onPress={() => nav.navigate('Editor', { noteId: item.id })}
              onLongPress={() => { haptic(); setMenuNote(item); }}
            />
          </View>
        )}
        ListEmptyComponent={
          <EmptyState
            icon="document-text-outline"
            title={query ? 'No matches' : 'No notes yet'}
            message={query ? 'Try a different search term.' : 'Capture your first thought - tap the + button to start writing.'}
            actionLabel={query ? undefined : 'Create a note'}
            onAction={query ? undefined : newNote}
          />
        }
      />

      <Animated.View style={[styles.fabWrap, { bottom: insets.bottom + 88, transform: [{ scale: fabScale }] }]}>
        <Pressable
          onPress={newNote}
          onPressIn={() => animateFab(0.9)}
          onPressOut={() => animateFab(1)}
          style={[styles.fab, { backgroundColor: colors.primary, shadowColor: colors.primary }]}
        >
          <Ionicons name="add" size={30} color="#fff" />
        </Pressable>
      </Animated.View>

      {/* note quick actions */}
      <Sheet visible={!!menuNote} onClose={() => setMenuNote(null)}>
        {menuNote && (
          <View>
            <Text numberOfLines={1} style={{ fontSize: 17, fontWeight: '800', color: colors.text, marginBottom: 4 }}>
              {menuNote.title || 'Untitled'}
            </Text>
            <Text style={{ fontSize: 12.5, color: colors.faint, marginBottom: 16 }}>
              Updated {formatFullDate(menuNote.updatedAt)}
            </Text>
            <Text style={{ fontSize: 12, fontWeight: '700', color: colors.faint, letterSpacing: 1, marginBottom: 10 }}>CARD COLOR</Text>
            <View style={{ flexDirection: 'row', gap: 10, marginBottom: 20, flexWrap: 'wrap' }}>
              {ACCENTS.map(c => (
                <Pressable
                  key={c}
                  onPress={() => { saveNote({ ...menuNote, color: c }); setMenuNote({ ...menuNote, color: c }); }}
                  style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: c, alignItems: 'center', justifyContent: 'center' }}
                >
                  {menuNote.color === c && <Ionicons name="checkmark" size={16} color="#fff" />}
                </Pressable>
              ))}
            </View>
            {([
              { icon: menuNote.pinned ? 'pin' : 'pin-outline', label: menuNote.pinned ? 'Unpin note' : 'Pin note', fn: () => togglePin(menuNote.id) },
              { icon: 'copy-outline', label: 'Make a copy', fn: () => { duplicateNote(menuNote.id); } },
              { icon: 'create-outline', label: 'Open editor', fn: () => nav.navigate('Editor', { noteId: menuNote.id }) },
            ] as const).map((a, i) => (
              <Pressable
                key={i}
                onPress={() => { a.fn(); setMenuNote(null); }}
                style={[styles.actionRow, { borderColor: colors.border }]}
              >
                <View style={[styles.actionIcon, { backgroundColor: colors.primarySoft }]}>
                  <Ionicons name={a.icon} size={17} color={colors.primary} />
                </View>
                <Text style={{ fontSize: 15, fontWeight: '600', color: colors.text }}>{a.label}</Text>
              </Pressable>
            ))}
            <Pressable
              onPress={() => { deleteNote(menuNote.id); setMenuNote(null); }}
              style={[styles.actionRow, { borderColor: colors.border }]}
            >
              <View style={[styles.actionIcon, { backgroundColor: soft('#E5484D', 0.12) }]}>
                <Ionicons name="trash-outline" size={17} color={colors.red} />
              </View>
              <Text style={{ fontSize: 15, fontWeight: '600', color: colors.red }}>Delete note</Text>
            </Pressable>
          </View>
        )}
      </Sheet>
    </View>
  );
}

const styles = StyleSheet.create({
  headerRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 18 },
  avatar: {
    width: 46, height: 46, borderRadius: 23,
    alignItems: 'center', justifyContent: 'center',
  },
  searchBar: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    paddingHorizontal: 16, paddingVertical: 13,
    borderRadius: 18, borderWidth: 1, marginBottom: 22,
  },
  searchInput: { flex: 1, fontSize: 15, padding: 0, outlineStyle: 'none' } as object,
  nbCard: {
    width: 118, padding: 13, borderRadius: 20, borderWidth: 1,
    shadowOpacity: 1, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 2,
  },
  fabWrap: { position: 'absolute', right: 22 },
  fab: {
    width: 62, height: 62, borderRadius: 22,
    alignItems: 'center', justifyContent: 'center',
    shadowOpacity: 0.4, shadowRadius: 16, shadowOffset: { width: 0, height: 8 }, elevation: 10,
  },
  actionRow: {
    flexDirection: 'row', alignItems: 'center', gap: 13,
    paddingVertical: 12, borderTopWidth: 1,
  },
  actionIcon: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
});
