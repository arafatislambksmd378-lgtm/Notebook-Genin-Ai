import React, { useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp } from '../store/AppContext';
import { useTheme } from '../store/ThemeContext';
import { RootStackParamList } from '../navigation';
import { NotebookIcon } from '../components/NotebookIcon';
import { ColorRow, Sheet, SheetHeader } from '../components/ui';
import { ACCENTS, NOTEBOOK_ICONS, soft } from '../theme';
import { Notebook } from '../types';
import { haptic } from '../lib/storage';

type Nav = NativeStackNavigationProp<RootStackParamList>;

export default function NotebooksScreen() {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const nav = useNavigation<Nav>();
  const { notebooks, notes, createNotebook, updateNotebook, deleteNotebook } = useApp();

  const [editorVisible, setEditorVisible] = useState(false);
  const [editing, setEditing] = useState<Notebook | null>(null);
  const [name, setName] = useState('');
  const [color, setColor] = useState(ACCENTS[0]);
  const [icon, setIcon] = useState(NOTEBOOK_ICONS[0]);

  const openCreate = () => {
    setEditing(null);
    setName('');
    setColor(ACCENTS[notebooks.length % ACCENTS.length]);
    setIcon(NOTEBOOK_ICONS[notebooks.length % NOTEBOOK_ICONS.length]);
    setEditorVisible(true);
  };

  const openEdit = (nb: Notebook) => {
    setEditing(nb);
    setName(nb.name);
    setColor(nb.color);
    setIcon(nb.icon);
    setEditorVisible(true);
  };

  const save = () => {
    if (editing) updateNotebook({ ...editing, name: name.trim() || editing.name, color, icon });
    else createNotebook(name, color, icon);
    haptic('success');
    setEditorVisible(false);
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <FlatList
        data={notebooks}
        keyExtractor={nb => nb.id}
        contentContainerStyle={{ padding: 20, paddingBottom: 120, paddingTop: insets.top + 12 }}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={
          <View style={{ marginBottom: 18 }}>
            <Text style={{ fontSize: 27, fontWeight: '800', color: colors.text, letterSpacing: -0.6 }}>Notebooks</Text>
            <Text style={{ fontSize: 13.5, color: colors.faint, fontWeight: '600', marginTop: 3 }}>
              {notebooks.length} notebooks · {notes.length} notes total
            </Text>
          </View>
        }
        ItemSeparatorComponent={() => <View style={{ height: 12 }} />}
        renderItem={({ item: nb }) => {
          const count = notes.filter(n => n.notebookId === nb.id).length;
          return (
            <Pressable
              onPress={() => nav.navigate('NotebookDetail', { notebookId: nb.id })}
              onLongPress={() => { haptic(); openEdit(nb); }}
              delayLongPress={350}
              style={[styles.row, { backgroundColor: colors.card, borderColor: colors.border, shadowColor: colors.shadow }]}
            >
              <NotebookIcon icon={nb.icon} color={nb.color} size={50} />
              <View style={{ flex: 1, marginLeft: 14 }}>
                <Text style={{ fontSize: 16.5, fontWeight: '700', color: colors.text }}>{nb.name}</Text>
                <Text style={{ fontSize: 12.5, color: colors.faint, fontWeight: '600', marginTop: 2 }}>
                  {count} {count === 1 ? 'note' : 'notes'}
                </Text>
              </View>
              <View style={[styles.countPill, { backgroundColor: soft(nb.color, 0.12) }]}>
                <Text style={{ fontSize: 13, fontWeight: '800', color: nb.color }}>{count}</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={colors.faint} style={{ marginLeft: 8 }} />
            </Pressable>
          );
        }}
      />

      <Pressable
        onPress={openCreate}
        style={[styles.newBtn, { bottom: insets.bottom + 92, backgroundColor: colors.card, borderColor: colors.primary, shadowColor: colors.shadow }]}
      >
        <Ionicons name="add" size={20} color={colors.primary} />
        <Text style={{ color: colors.primary, fontWeight: '700', fontSize: 14.5 }}>New notebook</Text>
      </Pressable>

      <Sheet visible={editorVisible} onClose={() => setEditorVisible(false)}>
        <SheetHeader title={editing ? 'Edit notebook' : 'New notebook'} onClose={() => setEditorVisible(false)} />
        <Text style={styles.label}>NAME</Text>
        <TextInput
          value={name}
          onChangeText={setName}
          placeholder="e.g. Reading list"
          placeholderTextColor={colors.faint}
          autoFocus
          style={[styles.input, { backgroundColor: colors.inputBg, color: colors.text, borderColor: colors.border }]}
        />
        <Text style={styles.label}>COLOR</Text>
        <ColorRow colors={ACCENTS} selected={color} onSelect={setColor} />
        <Text style={styles.label}>ICON</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 22 }}>
          {NOTEBOOK_ICONS.map(ic => (
            <Pressable
              key={ic}
              onPress={() => setIcon(ic)}
              style={[styles.iconPick, {
                backgroundColor: icon === ic ? soft(color, 0.16) : colors.surface,
                borderColor: icon === ic ? color : colors.border,
              }]}
            >
              <Ionicons name={ic as keyof typeof Ionicons.glyphMap} size={20} color={icon === ic ? color : colors.subtext} />
            </Pressable>
          ))}
        </View>
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <Pressable onPress={save} style={[styles.primaryBtn, { backgroundColor: colors.primary, flex: 1 }]}>
            <Text style={{ color: '#fff', fontWeight: '700', fontSize: 15 }}>{editing ? 'Save changes' : 'Create notebook'}</Text>
          </Pressable>
          {editing && notebooks.length > 1 && (
            <Pressable
              onPress={() => { deleteNotebook(editing.id); setEditorVisible(false); }}
              style={[styles.primaryBtn, { backgroundColor: colors.redSoft, paddingHorizontal: 18 }]}
            >
              <Ionicons name="trash-outline" size={18} color={colors.red} />
            </Pressable>
          )}
        </View>
        {editing && notebooks.length > 1 && (
          <Text style={{ fontSize: 11.5, color: colors.faint, textAlign: 'center', marginTop: 10 }}>
            Deleting moves its notes to {notebooks.find(n => n.id !== editing.id)?.name}.
          </Text>
        )}
      </Sheet>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row', alignItems: 'center',
    padding: 14, borderRadius: 22, borderWidth: 1,
    shadowOpacity: 1, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 2,
  },
  countPill: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 12 },
  newBtn: {
    position: 'absolute', right: 22, flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: 18, paddingVertical: 13, borderRadius: 20,
    borderWidth: 1.5, shadowOpacity: 1, shadowRadius: 12, shadowOffset: { width: 0, height: 6 }, elevation: 5,
  },
  label: { fontSize: 11.5, fontWeight: '800', color: '#A29EB0', letterSpacing: 1, marginBottom: 8, marginTop: 14 },
  input: {
    borderRadius: 14, paddingHorizontal: 16, paddingVertical: 13,
    fontSize: 15.5, borderWidth: 1, outlineStyle: 'none',
  } as object,
  iconPick: {
    width: 44, height: 44, borderRadius: 15, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1.5,
  },
  primaryBtn: {
    alignItems: 'center', justifyContent: 'center',
    paddingVertical: 14, borderRadius: 16,
  },
});
