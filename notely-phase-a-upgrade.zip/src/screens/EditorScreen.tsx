import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert, FlatList, Keyboard, KeyboardAvoidingView, Linking, Platform,
  Pressable, StyleSheet, Text, TextInput, View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import Ionicons from '@expo/vector-icons/Ionicons';
import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';

import { useApp } from '../store/AppContext';
import { useTheme } from '../store/ThemeContext';
import { RootStackParamList } from '../navigation';
import {
  Block, ChartBlock, DrawingBlock, EquationBlock, Note,
  TableBlock, TextBlock, VersionEntry, makeTextBlock,
} from '../types';
import { formatDateTime, tocEntries, uid } from '../lib/utils';
import { checkNote, SpellIssue, applyIssueFix } from '../lib/spell';
import { haptic } from '../lib/storage';
import { soft } from '../theme';

import FormatToolbar, { STYLE_DEFAULT_SIZE, STYLE_LABELS } from '../editor/FormatToolbar';
import InsertSheet, { InsertAction } from '../editor/InsertSheet';
import OverflowMenu, { MenuAction } from '../editor/OverflowMenu';
import DrawingCanvas from '../editor/DrawingCanvas';
import TableEditor from '../editor/TableEditor';
import ChartEditor from '../editor/ChartEditor';
import PageSetupSheet from '../editor/PageSetupSheet';
import {
  BookmarksSheet, CommentsSheet, FindReplaceSheet,
  SpellSheet, VersionsSheet, WordCountSheet,
} from '../editor/ToolSheets';
import {
  DictateModal, EquationEditor, ExportSheet,
  FootnoteModal, LinkModal, SpecialCharsSheet,
} from '../editor/InsertModals';
import { ChartView } from '../components/ChartView';
import { DrawingView } from '../components/DrawingView';
import { EquationView } from '../components/EquationView';
import { Sheet, SheetHeader } from '../components/ui';

type Nav = NativeStackNavigationProp<RootStackParamList>;

type ModalKey =
  | 'insert' | 'overflow' | 'drawing' | 'table' | 'chart' | 'page'
  | 'find' | 'words' | 'versions' | 'comments' | 'bookmarks' | 'spell'
  | 'export' | 'link' | 'footnote' | 'special' | 'equation' | 'dictate'
  | 'notebook' | 'delete' | null;

const STYLE_WEIGHT: Record<string, '400' | '600' | '700' | '800'> = {
  normal: '400', title: '800', h1: '800', h2: '700', h3: '700',
  h4: '600', h5: '600', h6: '700',
};

export default function EditorScreen() {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const nav = useNavigation<Nav>();
  const route = useRoute<RouteProp<RootStackParamList, 'Editor'>>();
  const { getNote, saveNote, deleteNote, duplicateNote, togglePin, notebooks, settings } = useApp();

  const [note, setNote] = useState<Note | null>(() => {
    const n = getNote(route.params.noteId);
    return n ? JSON.parse(JSON.stringify(n)) : null;
  });
  const [focusId, setFocusId] = useState<string | null>(null);
  const [showFormat, setShowFormat] = useState(true);
  const [modal, setModal] = useState<ModalKey>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [toast, setToast] = useState('');
  const [savedAt, setSavedAt] = useState<number | null>(Date.now());
  const [spellIssues, setSpellIssues] = useState<SpellIssue[]>([]);

  const inputRefs = useRef(new Map<string, TextInput>());
  const selRef = useRef<Record<string, { start: number; end: number }>>({});
  const pendingFocus = useRef<string | null>(null);
  const listRef = useRef<FlatList<Block>>(null);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const ignoredIssues = useRef<Set<string>>(new Set());
  const noteRef = useRef(note);
  noteRef.current = note;

  /* ------------------------------ auto-save ------------------------------ */
  useEffect(() => {
    if (!note) return;
    setSavedAt(null);
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      saveNote(note);
      setSavedAt(Date.now());
    }, 900);
    return () => { if (saveTimer.current) clearTimeout(saveTimer.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [note]);

  useEffect(() => () => {
    const n = noteRef.current;
    if (n) saveNote(n);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const showToast = (msg: string) => {
    setToast(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(''), 2200);
  };

  /* ------------------------------ note edits ----------------------------- */
  const update = (fn: (n: Note) => Note) =>
    setNote(prev => {
      if (!prev) return prev;
      return { ...fn(prev), updatedAt: Date.now() };
    });

  const patchBlock = (id: string, patch: Partial<Block>) =>
    update(n => ({
      ...n,
      blocks: n.blocks.map(b => (b.id === id ? ({ ...b, ...patch } as Block) : b)),
    }));

  const removeBlock = (id: string) => {
    haptic('medium');
    update(n => {
      if (n.blocks.length <= 1) return { ...n, blocks: [makeTextBlock(uid())] };
      return { ...n, blocks: n.blocks.filter(b => b.id !== id) };
    });
  };

  const insertBlock = (block: Block) => {
    update(n => {
      const idx = focusId ? n.blocks.findIndex(b => b.id === focusId) : -1;
      const at = idx >= 0 ? idx + 1 : n.blocks.length;
      return { ...n, blocks: [...n.blocks.slice(0, at), block, ...n.blocks.slice(at)] };
    });
  };

  const focusedBlock = useMemo(() => {
    if (!note || !focusId) return null;
    const b = note.blocks.find(x => x.id === focusId);
    return b && b.type === 'text' ? (b as TextBlock) : null;
  }, [note, focusId]);

  const patchFocused = (patch: Partial<TextBlock>) => {
    if (focusedBlock) patchBlock(focusedBlock.id, patch);
  };

  const insertTextAtCursor = (snippet: string) => {
    if (!note) return;
    if (!focusedBlock) {
      const b = makeTextBlock(uid(), snippet);
      insertBlock(b);
      pendingFocus.current = b.id;
      return;
    }
    const sel = selRef.current[focusedBlock.id] || { start: focusedBlock.text.length, end: focusedBlock.text.length };
    const text = focusedBlock.text.slice(0, sel.start) + snippet + focusedBlock.text.slice(sel.end);
    patchBlock(focusedBlock.id, { text });
  };

  /* --------------------------- text input behavior ------------------------ */
  const onChangeBlockText = (block: TextBlock, text: string) => {
    if (text.includes('\n')) {
      const parts = text.split('\n');
      const before = parts[0];
      const after = parts.slice(1).join('\n');
      const newBlock: TextBlock = {
        ...makeTextBlock(uid(), after),
        style: ['title', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'].includes(block.style) ? 'normal' : block.style,
        list: block.list,
        indent: block.indent,
      };
      update(n => {
        const idx = n.blocks.findIndex(b => b.id === block.id);
        const blocks = [...n.blocks];
        blocks[idx] = { ...block, text: before };
        blocks.splice(idx + 1, 0, newBlock);
        return { ...n, blocks };
      });
      pendingFocus.current = newBlock.id;
      return;
    }
    patchBlock(block.id, { text });
  };

  const onBlockKeyPress = (block: TextBlock, key: string) => {
    if (key !== 'Backspace') return;
    const sel = selRef.current[block.id];
    if (sel && (sel.start !== 0 || sel.end !== 0)) return;
    if (!note) return;
    const idx = note.blocks.findIndex(b => b.id === block.id);
    if (idx <= 0) {
      if (block.text === '' && note.blocks.length > 1) removeBlock(block.id);
      return;
    }
    const prev = note.blocks[idx - 1];
    if (block.text === '') {
      removeBlock(block.id);
      if (prev.type === 'text') pendingFocus.current = prev.id;
      return;
    }
    if (prev.type === 'text') {
      const merged = prev.text + block.text;
      update(n => ({
        ...n,
        blocks: n.blocks
          .map(b => (b.id === prev.id ? { ...b, text: merged } as TextBlock : b))
          .filter(b => b.id !== block.id),
      }));
      pendingFocus.current = prev.id;
    }
  };

  /* --------------------------------- inserts ------------------------------ */
  const pickImage = async (camera: boolean) => {
    try {
      if (camera && Platform.OS !== 'web') {
        const perm = await ImagePicker.requestCameraPermissionsAsync();
        if (!perm.granted) { showToast('Camera permission is needed'); return; }
      }
      const base = { quality: 0.55, base64: Platform.OS === 'web' };
      const res = camera
        ? await ImagePicker.launchCameraAsync(base)
        : await ImagePicker.launchImageLibraryAsync({ ...base, mediaTypes: ['images'] as never });
      if (!res.canceled && res.assets && res.assets[0]) {
        const a = res.assets[0];
        const uri = Platform.OS === 'web' && a.base64 ? `data:image/jpeg;base64,${a.base64}` : a.uri;
        insertBlock({ id: uid(), type: 'image', uri });
        haptic('success');
      }
    } catch {
      showToast('Could not open the image picker');
    }
  };

  const onInsertAction = (a: InsertAction) => {
    setModal(null);
    switch (a) {
      case 'image-gallery': pickImage(false); break;
      case 'image-camera': pickImage(true); break;
      case 'table': setEditingId(null); setModal('table'); break;
      case 'drawing': setEditingId(null); setModal('drawing'); break;
      case 'chart': setEditingId(null); setModal('chart'); break;
      case 'link': setModal('link'); break;
      case 'comment': setModal('comments'); break;
      case 'divider': insertBlock({ id: uid(), type: 'divider' }); break;
      case 'footnote': setModal('footnote'); break;
      case 'special': setModal('special'); break;
      case 'equation': setEditingId(null); setModal('equation'); break;
      case 'toc': {
        const exists = note?.blocks.some(b => b.type === 'toc');
        if (exists) showToast('Table of contents already on the page');
        else insertBlock({ id: uid(), type: 'toc' });
        break;
      }
      case 'bookmark': {
        if (!note) break;
        if (!focusId) { showToast('Place the cursor in a paragraph first'); break; }
        const b = note.blocks.find(x => x.id === focusId);
        const label = b && b.type === 'text' && b.text.trim()
          ? b.text.trim().slice(0, 42)
          : `Bookmark ${note.bookmarks.length + 1}`;
        update(n => ({ ...n, bookmarks: [...n.bookmarks, { id: uid(), blockId: focusId, label, at: Date.now() }] }));
        showToast('Bookmark saved');
        break;
      }
    }
  };

  const onMenuAction = (a: MenuAction) => {
    setModal(null);
    switch (a) {
      case 'page': setModal('page'); break;
      case 'find': setModal('find'); break;
      case 'words': setModal('words'); break;
      case 'spell': runSpellCheck(); break;
      case 'versions': setModal('versions'); break;
      case 'comments': setModal('comments'); break;
      case 'bookmarks': setModal('bookmarks'); break;
      case 'export': setModal('export'); break;
      case 'notebook': setModal('notebook'); break;
      case 'copy': {
        if (note) { duplicateNote(note.id); showToast('Copy created in your library'); }
        break;
      }
      case 'pin': if (note) { togglePin(note.id); update(n => ({ ...n, pinned: !n.pinned })); } break;
      case 'delete': setModal('delete'); break;
    }
  };

  const runSpellCheck = () => {
    if (!note) return;
    const issues = checkNote(note.blocks).filter(i => !ignoredIssues.current.has(i.type + i.wrong));
    setSpellIssues(issues);
    setModal('spell');
  };

  const jumpToBlock = (blockId: string) => {
    if (!note) return;
    const idx = note.blocks.findIndex(b => b.id === blockId);
    if (idx < 0) { showToast('That paragraph no longer exists'); return; }
    try {
      listRef.current?.scrollToIndex({ index: idx, viewPosition: 0.25, animated: true });
    } catch { /* handled by onScrollToIndexFailed */ }
  };

  /* ------------------------------ list helpers ---------------------------- */
  const numbering = useMemo(() => {
    if (!note) return new Map<string, number>();
    const map = new Map<string, number>();
    let counter = 0;
    for (const b of note.blocks) {
      if (b.type === 'text' && b.list === 'number') {
        counter += 1;
        map.set(b.id, counter);
      } else {
        counter = 0;
      }
    }
    return map;
  }, [note]);

  const toc = useMemo(() => (note ? tocEntries(note.blocks) : []), [note]);

  /* ------------------------------- renderers ------------------------------ */

  const textInputStyle = (b: TextBlock) => {
    const size = b.fontSize || STYLE_DEFAULT_SIZE[b.style];
    return {
      fontSize: size,
      lineHeight: size * 1.5,
      fontWeight: (b.bold ? '800' : STYLE_WEIGHT[b.style]) as '400' | '600' | '700' | '800',
      fontStyle: b.italic ? ('italic' as const) : ('normal' as const),
      textDecorationLine: ([b.underline && 'underline', b.strike && 'line-through'].filter(Boolean).join(' ') || 'none') as 'none' | 'underline' | 'line-through' | 'underline line-through',
      color: b.color || colors.text,
      backgroundColor: b.highlight || 'transparent',
      textAlign: b.align,
      letterSpacing: b.style === 'h6' ? 1.2 : 0,
      textTransform: (b.style === 'h6' ? 'uppercase' : 'none') as 'uppercase' | 'none',
    };
  };

  const renderTextBlock = (b: TextBlock) => {
    const size = b.fontSize || STYLE_DEFAULT_SIZE[b.style];
    const hasComment = note?.comments.some(c => c.blockId === b.id);
    const hasBookmark = note?.bookmarks.some(x => x.blockId === b.id);
    return (
      <View
        style={{
          flexDirection: 'row',
          marginTop: b.spaceBefore ? 16 : 2,
          marginBottom: b.spaceAfter ? 16 : 2,
          paddingLeft: b.indent * 26,
        }}
      >
        {b.list !== 'none' && (
          <Text style={{
            width: 24, textAlign: b.list === 'number' ? 'right' : 'center',
            paddingRight: b.list === 'number' ? 4 : 0,
            fontSize: b.list === 'bullet' ? size : size * 0.92,
            fontWeight: '700', color: colors.primary, lineHeight: size * 1.5,
          }}>
            {b.list === 'bullet' ? '\u2022' : `${numbering.get(b.id) || 1}.`}
          </Text>
        )}
        <View style={{ flex: 1 }}>
          <TextInput
            ref={r => {
              if (r) {
                inputRefs.current.set(b.id, r);
                if (pendingFocus.current === b.id) {
                  pendingFocus.current = null;
                  setTimeout(() => r.focus(), 60);
                }
              } else {
                inputRefs.current.delete(b.id);
              }
            }}
            value={b.text}
            onChangeText={t => onChangeBlockText(b, t)}
            onFocus={() => setFocusId(b.id)}
            onSelectionChange={e => { selRef.current[b.id] = e.nativeEvent.selection; }}
            onKeyPress={e => onBlockKeyPress(b, e.nativeEvent.key)}
            placeholder={b.style === 'title' ? 'Title' : b.style.startsWith('h') ? STYLE_LABELS[b.style] : focusId === b.id ? 'Type / for ideas\u2026' : ''}
            placeholderTextColor={colors.faint}
            multiline
            spellCheck={settings.spellcheck}
            autoCapitalize="sentences"
            scrollEnabled={false}
            style={[textInputStyle(b), styles.textInput]}
          />
          {(hasComment || hasBookmark || b.links.length > 0) && (
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 4 }}>
              {b.links.map((l, i) => (
                <Pressable
                  key={i}
                  onPress={() => Linking.openURL(l.url).catch(() => showToast('Could not open link'))}
                  onLongPress={() => patchBlock(b.id, { links: b.links.filter((_x, li) => li !== i) })}
                  style={[styles.linkChip, { backgroundColor: colors.primarySoft }]}
                >
                  <Ionicons name="link" size={10} color={colors.primary} />
                  <Text style={{ fontSize: 11, fontWeight: '700', color: colors.primary }}>
                    {b.text.slice(l.start, l.end).slice(0, 22) || l.url}
                  </Text>
                </Pressable>
              ))}
              {hasComment && (
                <Pressable onPress={() => setModal('comments')} style={[styles.linkChip, { backgroundColor: colors.yellowSoft }]}>
                  <Ionicons name="chatbubble" size={10} color={colors.yellow} />
                  <Text style={{ fontSize: 11, fontWeight: '700', color: colors.yellow }}>Comment</Text>
                </Pressable>
              )}
              {hasBookmark && (
                <View style={[styles.linkChip, { backgroundColor: colors.primarySoft }]}>
                  <Ionicons name="bookmark" size={10} color={colors.primary} />
                </View>
              )}
            </View>
          )}
        </View>
      </View>
    );
  };

  const blockShell = (b: Block, children: React.ReactNode, onEdit?: () => void) => (
    <View style={[styles.blockShell, { borderColor: colors.border }]}>
      {children}
      <View style={styles.blockTools}>
        {onEdit && (
          <Pressable onPress={onEdit} hitSlop={6} style={[styles.blockTool, { backgroundColor: colors.primarySoft }]}>
            <Ionicons name="create" size={12} color={colors.primary} />
          </Pressable>
        )}
        <Pressable onPress={() => removeBlock(b.id)} hitSlop={6} style={[styles.blockTool, { backgroundColor: colors.redSoft }]}>
          <Ionicons name="trash" size={12} color={colors.red} />
        </Pressable>
      </View>
    </View>
  );

  const renderBlock = ({ item: b }: { item: Block }) => {
    switch (b.type) {
      case 'text': return renderTextBlock(b);
      case 'image':
        return blockShell(b, (
          <View>
            <Image source={{ uri: b.uri }} style={{ width: '100%', height: b.height || 210, borderRadius: 12 }} contentFit="cover" transition={180} />
            <TextInput
              value={b.caption || ''}
              onChangeText={v => patchBlock(b.id, { caption: v })}
              placeholder="Add a caption\u2026"
              placeholderTextColor={colors.faint}
              style={{ fontSize: 12, color: colors.subtext, marginTop: 6, textAlign: 'center', outlineStyle: 'none' } as object}
            />
          </View>
        ));
      case 'table':
        return blockShell(b, (
          <View style={{ borderRadius: 10, overflow: 'hidden', borderWidth: 1, borderColor: colors.border }}>
            {b.rows.map((row, ri) => (
              <View key={ri} style={{ flexDirection: 'row' }}>
                {row.map((cell, ci) => (
                  <View key={ci} style={{
                    flex: 1, paddingHorizontal: 9, paddingVertical: 8,
                    backgroundColor: ri === 0 ? colors.primarySoft : 'transparent',
                    borderRightWidth: ci < row.length - 1 ? 1 : 0, borderTopWidth: ri > 0 ? 1 : 0,
                    borderColor: colors.border,
                  }}>
                    <Text style={{ fontSize: 12.5, color: colors.text, fontWeight: ri === 0 ? '700' : '400' }}>{cell || '\u00a0'}</Text>
                  </View>
                ))}
              </View>
            ))}
          </View>
        ), () => { setEditingId(b.id); setModal('table'); });
      case 'drawing':
        return blockShell(b, <DrawingView block={b} />, () => { setEditingId(b.id); setModal('drawing'); });
      case 'chart':
        return blockShell(b, <ChartView block={b} />, () => { setEditingId(b.id); setModal('chart'); });
      case 'divider':
        return blockShell(b, <View style={{ height: 2, backgroundColor: colors.border, borderRadius: 1, marginVertical: 12 }} />);
      case 'equation':
        return blockShell(b, <EquationView expr={b.expr} />, () => { setEditingId(b.id); setModal('equation'); });
      case 'toc':
        return blockShell(b, (
          <View style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 14, padding: 14, backgroundColor: soft(colors.primary, 0.03) }}>
            <Text style={{ fontSize: 14, fontWeight: '800', color: colors.text, marginBottom: 8 }}>Table of Contents</Text>
            {toc.length === 0 && <Text style={{ fontSize: 12.5, color: colors.faint, fontStyle: 'italic' }}>Add headings to build the outline automatically.</Text>}
            {toc.map(e => (
              <Pressable key={e.id} onPress={() => jumpToBlock(e.id)} style={{ paddingLeft: e.level * 16, paddingVertical: 3, flexDirection: 'row', alignItems: 'center' }}>
                <View style={{ width: 5, height: 5, borderRadius: 3, backgroundColor: colors.primary, marginRight: 8 }} />
                <Text style={{ fontSize: 13.5, color: colors.primary, fontWeight: '600' }}>{e.text}</Text>
              </Pressable>
            ))}
          </View>
        ));
      default: return null;
    }
  };

  if (!note) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center' }}>
        <Text style={{ color: colors.subtext }}>Note not found</Text>
        <Pressable onPress={() => nav.goBack()} style={{ marginTop: 14 }}>
          <Text style={{ color: colors.primary, fontWeight: '700' }}>Go back</Text>
        </Pressable>
      </View>
    );
  }

  const page = note.page;
  const baseMax = page.paper === 'A5' ? 560 : page.paper === 'Custom' ? page.customW * 88 : page.paper === 'Letter' ? 780 : 760;
  const pageMaxW = page.orientation === 'landscape' ? baseMax * 1.38 : baseMax;
  const editingBlock = editingId ? note.blocks.find(b => b.id === editingId) : null;

  const savedLabel = savedAt
    ? `Saved \u00b7 ${formatDateTime(savedAt).split('\u00b7')[1] || ''}`
    : 'Saving\u2026';

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      {/* header */}
      <View style={[styles.header, { paddingTop: insets.top + 6, backgroundColor: colors.card, borderBottomColor: colors.border }]}>
        <Pressable onPress={() => { saveNote(note); nav.goBack(); }} hitSlop={8} style={[styles.headerBtn, { backgroundColor: colors.surface }]}>
          <Ionicons name="chevron-back" size={20} color={colors.text} />
        </Pressable>
        <View style={{ flex: 1, marginHorizontal: 10 }}>
          <TextInput
            value={note.title}
            onChangeText={v => update(n => ({ ...n, title: v }))}
            placeholder="Untitled"
            placeholderTextColor={colors.faint}
            style={[styles.titleInput, { color: colors.text }]}
          />
          <Text style={{ fontSize: 10.5, color: savedAt ? colors.faint : colors.yellow, fontWeight: '600', marginTop: 1 }}>
            {savedLabel}
          </Text>
        </View>
        <Pressable onPress={() => setModal('comments')} hitSlop={8} style={[styles.headerBtn, { backgroundColor: colors.surface }]}>
          <Ionicons name="chatbubbles-outline" size={18} color={colors.subtext} />
          {note.comments.length > 0 && (
            <View style={[styles.badgeDot, { backgroundColor: colors.yellow }]}>
              <Text style={{ fontSize: 8.5, fontWeight: '800', color: '#fff' }}>{note.comments.length}</Text>
            </View>
          )}
        </Pressable>
        <Pressable onPress={() => { togglePin(note.id); update(n => ({ ...n, pinned: !n.pinned })); }} hitSlop={8}
          style={[styles.headerBtn, { backgroundColor: note.pinned ? colors.primarySoft : colors.surface }]}>
          <Ionicons name={note.pinned ? 'pin' : 'pin-outline'} size={17} color={note.pinned ? colors.primary : colors.subtext} />
        </Pressable>
        <Pressable onPress={() => setModal('overflow')} hitSlop={8} style={[styles.headerBtn, { backgroundColor: colors.surface }]}>
          <Ionicons name="ellipsis-horizontal" size={18} color={colors.subtext} />
        </Pressable>
      </View>

      {/* format toolbar */}
      <FormatToolbar block={focusedBlock} onPatch={patchFocused} visible={showFormat} />

      {/* page */}
      <View style={{ flex: 1, backgroundColor: colors.surface }}>
        <FlatList
          ref={listRef}
          data={note.blocks}
          keyExtractor={b => b.id}
          renderItem={renderBlock}
          keyboardShouldPersistTaps="always"
          showsVerticalScrollIndicator={false}
          onScrollToIndexFailed={({ index }) => {
            listRef.current?.scrollToOffset({ offset: index * 90, animated: true });
          }}
          style={[styles.page, {
            maxWidth: pageMaxW, backgroundColor: page.pageColor,
            shadowColor: colors.shadow,
          }]}
          contentContainerStyle={{
            paddingHorizontal: page.margin, paddingTop: Math.max(20, page.margin * 0.7),
            paddingBottom: 160, flexGrow: 1,
          }}
          ListFooterComponent={
            <View>
              {note.footnotes.length > 0 && (
                <View style={{ marginTop: 26, borderTopWidth: 1, borderTopColor: colors.border, paddingTop: 12 }}>
                  <Text style={{ fontSize: 10.5, fontWeight: '800', color: colors.faint, letterSpacing: 1, marginBottom: 8 }}>FOOTNOTES</Text>
                  {note.footnotes.map((fn, i) => (
                    <View key={fn.id} style={{ flexDirection: 'row', alignItems: 'flex-start', marginBottom: 5 }}>
                      <Text style={{ fontSize: 11.5, fontWeight: '700', color: colors.primary, width: 22 }}>[{i + 1}]</Text>
                      <Text style={{ flex: 1, fontSize: 12.5, color: colors.subtext, lineHeight: 18 }}>{fn.text}</Text>
                      <Pressable onPress={() => update(n => ({ ...n, footnotes: n.footnotes.filter(f => f.id !== fn.id) }))} hitSlop={8}>
                        <Ionicons name="close" size={13} color={colors.faint} />
                      </Pressable>
                    </View>
                  ))}
                </View>
              )}
              <Pressable
                onPress={() => {
                  const b = makeTextBlock(uid());
                  update(n => ({ ...n, blocks: [...n.blocks, b] }));
                  pendingFocus.current = b.id;
                }}
                style={{ paddingVertical: 26, alignItems: 'center' }}
              >
                <Text style={{ fontSize: 13, color: colors.faint, fontWeight: '600' }}>Tap to keep writing</Text>
              </Pressable>
            </View>
          }
        />
      </View>

      {/* bottom bar */}
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={[styles.bottomBar, { paddingBottom: Math.max(insets.bottom, 10), backgroundColor: colors.card, borderTopColor: colors.border }]}>
          <Pressable onPress={() => setModal('insert')} style={[styles.barBtn, { backgroundColor: colors.primary }]}>
            <Ionicons name="add" size={22} color="#fff" />
          </Pressable>
          <Pressable onPress={() => setShowFormat(v => !v)} style={[styles.barBtnSm, { backgroundColor: showFormat ? colors.primarySoft : colors.surface }]}>
            <Text style={{ fontSize: 15, fontWeight: '800', color: showFormat ? colors.primary : colors.subtext }}>Aa</Text>
          </Pressable>
          <Pressable onPress={() => pickImage(false)} style={[styles.barBtnSm, { backgroundColor: colors.surface }]}>
            <Ionicons name="image-outline" size={19} color={colors.subtext} />
          </Pressable>
          <Pressable onPress={() => setModal('dictate')} style={[styles.barBtnSm, { backgroundColor: colors.surface }]}>
            <Ionicons name="mic-outline" size={19} color={colors.subtext} />
          </Pressable>
          <Pressable onPress={() => setModal('find')} style={[styles.barBtnSm, { backgroundColor: colors.surface }]}>
            <Ionicons name="search-outline" size={19} color={colors.subtext} />
          </Pressable>
          <Pressable onPress={() => Keyboard.dismiss()} style={[styles.barBtnSm, { backgroundColor: colors.surface }]}>
            <Ionicons name="chevron-down" size={20} color={colors.subtext} />
          </Pressable>
        </View>
      </KeyboardAvoidingView>

      {/* toast */}
      {!!toast && (
        <View style={[styles.toast, { backgroundColor: colors.text, bottom: Math.max(insets.bottom, 10) + 72 }]}>
          <Text style={{ color: colors.bg, fontSize: 13, fontWeight: '600' }}>{toast}</Text>
        </View>
      )}

      {/* ------------------------------ modals ------------------------------ */}
      <InsertSheet visible={modal === 'insert'} onClose={() => setModal(null)} onAction={onInsertAction} />
      <OverflowMenu
        visible={modal === 'overflow'}
        onClose={() => setModal(null)}
        onAction={onMenuAction}
        pinned={note.pinned}
        noteColor={note.color}
        onColor={c => update(n => ({ ...n, color: c }))}
        commentCount={note.comments.length}
        versionCount={note.versions.length}
      />
      <DrawingCanvas
        visible={modal === 'drawing'}
        onClose={() => { setModal(null); setEditingId(null); }}
        pageColor={page.pageColor}
        existing={editingBlock?.type === 'drawing' ? (editingBlock as DrawingBlock) : null}
        onSave={data => {
          if (editingId) patchBlock(editingId, data);
          else insertBlock({ id: uid(), ...data });
          setEditingId(null);
        }}
      />
      <TableEditor
        visible={modal === 'table'}
        onClose={() => { setModal(null); setEditingId(null); }}
        existing={editingBlock?.type === 'table' ? (editingBlock as TableBlock) : null}
        onSave={rows => {
          if (editingId) patchBlock(editingId, { rows });
          else insertBlock({ id: uid(), type: 'table', rows });
          setEditingId(null);
        }}
      />
      <ChartEditor
        visible={modal === 'chart'}
        onClose={() => { setModal(null); setEditingId(null); }}
        existing={editingBlock?.type === 'chart' ? (editingBlock as ChartBlock) : null}
        onSave={data => {
          if (editingId) patchBlock(editingId, data);
          else insertBlock({ id: uid(), ...data });
          setEditingId(null);
        }}
      />
      <EquationEditor
        visible={modal === 'equation'}
        onClose={() => { setModal(null); setEditingId(null); }}
        existing={editingBlock?.type === 'equation' ? (editingBlock as EquationBlock) : null}
        onSave={expr => {
          if (editingId) patchBlock(editingId, { expr });
          else insertBlock({ id: uid(), type: 'equation', expr });
          setEditingId(null);
        }}
      />
      <PageSetupSheet
        visible={modal === 'page'}
        onClose={() => setModal(null)}
        page={page}
        onChange={p => update(n => ({ ...n, page: p }))}
      />
      <FindReplaceSheet
        visible={modal === 'find'}
        onClose={() => setModal(null)}
        note={note}
        onApply={(find, replace, matchCase) => {
          let count = 0;
          update(n => ({
            ...n,
            blocks: n.blocks.map(b => {
              if (b.type !== 'text') return b;
              const t = b as TextBlock;
              if (!find) return t;
              if (matchCase) {
                const parts = t.text.split(find);
                count += parts.length - 1;
                return { ...t, text: parts.join(replace) };
              }
              const re = new RegExp(find.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
              const next = t.text.replace(re, () => { count++; return replace; });
              return { ...t, text: next };
            }),
          }));
          return count;
        }}
      />
      <WordCountSheet visible={modal === 'words'} onClose={() => setModal(null)} note={note} />
      <VersionsSheet
        visible={modal === 'versions'}
        onClose={() => setModal(null)}
        note={note}
        onRestore={(v: VersionEntry) => {
          update(n => ({ ...n, title: v.title, blocks: JSON.parse(JSON.stringify(v.blocks)) }));
          showToast('Version restored');
        }}
      />
      <CommentsSheet
        visible={modal === 'comments'}
        onClose={() => setModal(null)}
        note={note}
        focusedBlockId={focusId}
        onAdd={text => update(n => ({ ...n, comments: [...n.comments, { id: uid(), blockId: focusId || '', text, at: Date.now() }] }))}
        onDelete={id => update(n => ({ ...n, comments: n.comments.filter(c => c.id !== id) }))}
      />
      <BookmarksSheet
        visible={modal === 'bookmarks'}
        onClose={() => setModal(null)}
        note={note}
        onJump={jumpToBlock}
        onDelete={id => update(n => ({ ...n, bookmarks: n.bookmarks.filter(b => b.id !== id) }))}
      />
      <SpellSheet
        visible={modal === 'spell'}
        onClose={() => setModal(null)}
        issues={spellIssues}
        onFix={issue => {
          update(n => ({
            ...n,
            blocks: n.blocks.map(b => {
              if (b.id !== issue.blockId || b.type !== 'text') return b;
              return { ...b, text: applyIssueFix(b.text, issue) } as TextBlock;
            }),
          }));
          setSpellIssues(prev => prev.filter(i => i !== issue));
        }}
        onIgnore={issue => {
          ignoredIssues.current.add(issue.type + issue.wrong);
          setSpellIssues(prev => prev.filter(i => i !== issue));
        }}
      />
      <ExportSheet
        visible={modal === 'export'}
        onClose={() => setModal(null)}
        note={note}
        onDuplicate={() => duplicateNote(note.id)}
        onMessage={showToast}
      />
      <LinkModal
        visible={modal === 'link'}
        onClose={() => setModal(null)}
        onInsert={(label, url) => {
          if (focusedBlock) {
            const sel = selRef.current[focusedBlock.id] || { start: focusedBlock.text.length, end: focusedBlock.text.length };
            const text = focusedBlock.text.slice(0, sel.start) + label + focusedBlock.text.slice(sel.end);
            patchBlock(focusedBlock.id, {
              text,
              links: [...focusedBlock.links, { start: sel.start, end: sel.start + label.length, url }],
            });
          } else {
            insertTextAtCursor(label);
          }
        }}
      />
      <FootnoteModal
        visible={modal === 'footnote'}
        onClose={() => setModal(null)}
        nextNumber={note.footnotes.length + 1}
        onAdd={text => {
          update(n => ({ ...n, footnotes: [...n.footnotes, { id: uid(), text }] }));
          insertTextAtCursor(`[${note.footnotes.length + 1}]`);
        }}
      />
      <SpecialCharsSheet
        visible={modal === 'special'}
        onClose={() => setModal(null)}
        onPick={ch => insertTextAtCursor(ch)}
      />
      <DictateModal
        visible={modal === 'dictate'}
        onClose={() => setModal(null)}
        onInsert={text => insertTextAtCursor(text)}
      />

      {/* move to notebook */}
      <Sheet visible={modal === 'notebook'} onClose={() => setModal(null)}>
        <SheetHeader title="Move to notebook" onClose={() => setModal(null)} />
        {notebooks.map(nb => (
          <Pressable
            key={nb.id}
            onPress={() => { update(n => ({ ...n, notebookId: nb.id })); setModal(null); showToast(`Moved to ${nb.name}`); }}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 12 }}
          >
            <View style={{ width: 34, height: 34, borderRadius: 12, backgroundColor: soft(nb.color, 0.15), alignItems: 'center', justifyContent: 'center' }}>
              <Ionicons name={nb.icon as keyof typeof Ionicons.glyphMap} size={16} color={nb.color} />
            </View>
            <Text style={{ flex: 1, fontSize: 15, fontWeight: '600', color: colors.text }}>{nb.name}</Text>
            {note.notebookId === nb.id && <Ionicons name="checkmark-circle" size={18} color={colors.primary} />}
          </Pressable>
        ))}
      </Sheet>

      {/* delete confirm */}
      <Sheet visible={modal === 'delete'} onClose={() => setModal(null)} maxHeight={0.5}>
        <SheetHeader title="Delete this note?" onClose={() => setModal(null)} />
        <Text style={{ fontSize: 14, color: colors.subtext, lineHeight: 21, marginBottom: 20 }}>
          \u201c{note.title || 'Untitled'}\u201d and its version history will be permanently removed.
        </Text>
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <Pressable onPress={() => setModal(null)} style={[styles.dialogBtn, { backgroundColor: colors.surface }]}>
            <Text style={{ fontWeight: '700', color: colors.text }}>Cancel</Text>
          </Pressable>
          <Pressable
            onPress={() => { deleteNote(note.id); setModal(null); nav.goBack(); }}
            style={[styles.dialogBtn, { backgroundColor: colors.red }]}
          >
            <Text style={{ fontWeight: '700', color: '#fff' }}>Delete</Text>
          </Pressable>
        </View>
      </Sheet>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 12, paddingBottom: 10, borderBottomWidth: 1,
  },
  headerBtn: {
    width: 38, height: 38, borderRadius: 14,
    alignItems: 'center', justifyContent: 'center', marginLeft: 6,
  },
  badgeDot: {
    position: 'absolute', top: -4, right: -4,
    minWidth: 16, height: 16, borderRadius: 8,
    alignItems: 'center', justifyContent: 'center', paddingHorizontal: 3,
  },
  titleInput: { fontSize: 16.5, fontWeight: '800', padding: 0, outlineStyle: 'none' } as object,
  page: {
    flex: 1, width: '100%', alignSelf: 'center',
    marginTop: 14, borderTopLeftRadius: 14, borderTopRightRadius: 14,
    shadowOpacity: 1, shadowRadius: 18, shadowOffset: { width: 0, height: 6 }, elevation: 4,
  },
  textInput: { padding: 0, margin: 0, outlineStyle: 'none' } as object,
  linkChip: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, alignSelf: 'flex-start',
  },
  blockShell: { position: 'relative', marginVertical: 6 },
  blockTools: {
    position: 'absolute', top: -8, right: -4,
    flexDirection: 'row', gap: 5, zIndex: 5,
  },
  blockTool: {
    width: 24, height: 24, borderRadius: 8,
    alignItems: 'center', justifyContent: 'center',
  },
  bottomBar: {
    flexDirection: 'row', alignItems: 'center', gap: 9,
    paddingHorizontal: 14, paddingTop: 10, borderTopWidth: 1,
  },
  barBtn: { width: 46, height: 46, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  barBtnSm: { flex: 1, height: 46, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  toast: {
    position: 'absolute', alignSelf: 'center',
    paddingHorizontal: 18, paddingVertical: 11, borderRadius: 16,
    shadowColor: '#000', shadowOpacity: 0.2, shadowRadius: 12, shadowOffset: { width: 0, height: 4 }, elevation: 8,
  },
  dialogBtn: {
    flex: 1, alignItems: 'center', paddingVertical: 13, borderRadius: 14,
  },
});
