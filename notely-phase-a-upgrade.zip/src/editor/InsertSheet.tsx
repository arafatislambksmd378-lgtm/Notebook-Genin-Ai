import React, { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useTheme } from '../store/ThemeContext';
import { Sheet, SheetHeader } from '../components/ui';
import { soft } from '../theme';
import { haptic } from '../lib/storage';

export type InsertAction =
  | 'image-gallery' | 'image-camera' | 'table' | 'drawing' | 'chart'
  | 'link' | 'comment' | 'divider' | 'footnote' | 'special'
  | 'equation' | 'toc' | 'bookmark';

interface Item {
  key: InsertAction;
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  desc: string;
}

const ITEMS: Item[] = [
  { key: 'table', icon: 'grid', label: 'Table', desc: 'Rows & columns' },
  { key: 'drawing', icon: 'brush', label: 'Drawing', desc: 'Sketch & ink' },
  { key: 'chart', icon: 'bar-chart', label: 'Chart', desc: 'Graphs from data' },
  { key: 'link', icon: 'link', label: 'Link', desc: 'Hyperlink text' },
  { key: 'comment', icon: 'chatbubble-ellipses', label: 'Comment', desc: 'Side note on text' },
  { key: 'divider', icon: 'remove', label: 'Divider', desc: 'Horizontal line' },
  { key: 'footnote', icon: 'library', label: 'Footnote', desc: 'Bottom reference' },
  { key: 'special', icon: 'shapes', label: 'Symbols', desc: 'π © → ¥ ∑' },
  { key: 'equation', icon: 'calculator', label: 'Equation', desc: 'Math & science' },
  { key: 'toc', icon: 'list', label: 'Contents', desc: 'Auto from headings' },
  { key: 'bookmark', icon: 'bookmark', label: 'Bookmark', desc: 'Save position' },
];

const ACCENT_ORDER = ['#7C4DFF', '#2F7DE1', '#16A34A', '#E9A800', '#EC4899', '#14B8A6'];

export default function InsertSheet({
  visible, onClose, onAction,
}: {
  visible: boolean;
  onClose: () => void;
  onAction: (a: InsertAction) => void;
}) {
  const { colors } = useTheme();
  const [imageOpen, setImageOpen] = useState(false);

  const act = (a: InsertAction) => {
    haptic();
    onAction(a);
  };

  return (
    <Sheet visible={visible} onClose={() => { setImageOpen(false); onClose(); }} maxHeight={0.9}>
      <SheetHeader title="Insert" onClose={() => { setImageOpen(false); onClose(); }} />
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* image gets its own expandable row */}
        <View style={[styles.imageCard, { borderColor: colors.border, backgroundColor: colors.surface }]}>
          <Pressable onPress={() => setImageOpen(o => !o)} style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
            <View style={[styles.bigIcon, { backgroundColor: soft('#EC4899', 0.15) }]}>
              <Ionicons name="image" size={21} color="#EC4899" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 15, fontWeight: '700', color: colors.text }}>Image</Text>
              <Text style={{ fontSize: 11.5, color: colors.faint }}>From gallery or camera</Text>
            </View>
            <Ionicons name={imageOpen ? 'chevron-up' : 'chevron-down'} size={16} color={colors.faint} />
          </Pressable>
          {imageOpen && (
            <View style={{ flexDirection: 'row', gap: 10, marginTop: 12 }}>
              <Pressable onPress={() => act('image-gallery')}
                style={[styles.imageOpt, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Ionicons name="images" size={18} color={colors.primary} />
                <Text style={{ fontSize: 13, fontWeight: '700', color: colors.text, marginTop: 5 }}>Gallery</Text>
              </Pressable>
              <Pressable onPress={() => act('image-camera')}
                style={[styles.imageOpt, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Ionicons name="camera" size={18} color={colors.blue} />
                <Text style={{ fontSize: 13, fontWeight: '700', color: colors.text, marginTop: 5 }}>Camera</Text>
              </Pressable>
            </View>
          )}
        </View>

        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 10 }}>
          {ITEMS.map((it, i) => {
            const accent = ACCENT_ORDER[i % ACCENT_ORDER.length];
            return (
              <Pressable
                key={it.key}
                onPress={() => act(it.key)}
                style={[styles.cell, { backgroundColor: colors.card, borderColor: colors.border }]}
              >
                <View style={[styles.bigIcon, { backgroundColor: soft(accent, 0.14) }]}>
                  <Ionicons name={it.icon} size={21} color={accent} />
                </View>
                <Text style={{ fontSize: 13.5, fontWeight: '700', color: colors.text, marginTop: 9 }}>{it.label}</Text>
                <Text style={{ fontSize: 10.5, color: colors.faint, marginTop: 2 }}>{it.desc}</Text>
              </Pressable>
            );
          })}
        </View>
        <View style={{ height: 8 }} />
      </ScrollView>
    </Sheet>
  );
}

const styles = StyleSheet.create({
  imageCard: { borderWidth: 1, borderRadius: 18, padding: 13 },
  imageOpt: {
    flex: 1, alignItems: 'center', paddingVertical: 13,
    borderRadius: 14, borderWidth: 1,
  },
  bigIcon: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  cell: {
    width: '30.8%', flexGrow: 1, borderWidth: 1, borderRadius: 18,
    padding: 12, alignItems: 'flex-start',
  },
});
