import React, { useEffect, useRef, useState } from 'react';
import {
  Animated, Platform, Pressable, ScrollView, StyleSheet,
  Text, TextInput, View,
} from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useTheme } from '../store/ThemeContext';
import { Sheet, SheetHeader } from '../components/ui';
import { EQUATION_SNIPPETS, renderEquation } from '../lib/equation';
import { EquationBlock, Note } from '../types';
import { exportNote, ExportFormat, printNote, shareNote } from '../lib/export';
import { soft } from '../theme';
import { haptic } from '../lib/storage';

/* ---------------------------------- link ---------------------------------- */

export function LinkModal({
  visible, onClose, onInsert,
}: {
  visible: boolean;
  onClose: () => void;
  onInsert: (label: string, url: string) => void;
}) {
  const { colors } = useTheme();
  const [label, setLabel] = useState('');
  const [url, setUrl] = useState('');

  const insert = () => {
    const u = url.trim();
    if (!u) return;
    const full = /^https?:\/\//i.test(u) ? u : 'https://' + u;
    onInsert(label.trim() || full, full);
    setLabel(''); setUrl('');
    onClose();
  };

  return (
    <Sheet visible={visible} onClose={onClose}>
      <SheetHeader title="Insert link" onClose={onClose} />
      <View style={[styles.field, { backgroundColor: colors.inputBg, borderColor: colors.border }]}>
        <Ionicons name="text" size={15} color={colors.faint} />
        <TextInput value={label} onChangeText={setLabel} placeholder="Display text"
          placeholderTextColor={colors.faint} style={[styles.input, { color: colors.text }]} />
      </View>
      <View style={[styles.field, { backgroundColor: colors.inputBg, borderColor: colors.border }]}>
        <Ionicons name="link" size={15} color={colors.faint} />
        <TextInput value={url} onChangeText={setUrl} placeholder="example.com"
          placeholderTextColor={colors.faint} autoCapitalize="none" keyboardType="url"
          style={[styles.input, { color: colors.text }]} onSubmitEditing={insert} />
      </View>
      <Pressable onPress={insert} disabled={!url.trim()}
        style={[styles.primaryBtn, { backgroundColor: colors.primary, opacity: url.trim() ? 1 : 0.4 }]}>
        <Text style={{ color: '#fff', fontWeight: '700', fontSize: 14.5 }}>Insert link</Text>
      </Pressable>
    </Sheet>
  );
}

/* -------------------------------- footnote --------------------------------- */

export function FootnoteModal({
  visible, onClose, onAdd, nextNumber,
}: {
  visible: boolean;
  onClose: () => void;
  onAdd: (text: string) => void;
  nextNumber: number;
}) {
  const { colors } = useTheme();
  const [text, setText] = useState('');
  const add = () => {
    if (!text.trim()) return;
    onAdd(text.trim());
    setText('');
    onClose();
  };
  return (
    <Sheet visible={visible} onClose={onClose}>
      <SheetHeader title={`Footnote ${nextNumber}`} onClose={onClose} />
      <Text style={{ fontSize: 13, color: colors.subtext, marginBottom: 10 }}>
        A [{nextNumber}] marker is inserted at the cursor; the reference appears at the bottom of the page.
      </Text>
      <View style={[styles.field, { backgroundColor: colors.inputBg, borderColor: colors.border }]}>
        <TextInput value={text} onChangeText={setText} placeholder="Reference text, source, citation..."
          placeholderTextColor={colors.faint} multiline autoFocus
          style={[styles.input, { color: colors.text, minHeight: 44 }]} onSubmitEditing={add} />
      </View>
      <Pressable onPress={add} disabled={!text.trim()}
        style={[styles.primaryBtn, { backgroundColor: colors.primary, opacity: text.trim() ? 1 : 0.4 }]}>
        <Text style={{ color: '#fff', fontWeight: '700', fontSize: 14.5 }}>Add footnote</Text>
      </Pressable>
    </Sheet>
  );
}

/* ---------------------------- special characters --------------------------- */

const CHAR_GROUPS: { name: string; chars: string[] }[] = [
  { name: 'Symbols', chars: ['©', '®', '™', '°', '±', '§', '¶', '•', '‣', '✓', '✔', '✕', '★', '☆', '♥', '♦', '♣', '♠', '♪', '♫', '⚑', '✦', '✲', '☀', '☾', '✂', '✉', '✎', '⚙', '❤'] },
  { name: 'Currency', chars: ['$', '€', '£', '¥', '₹', '₩', '₽', '₿', '¢', '₦', '฿', '₴', '₭', '₸'] },
  { name: 'Math', chars: ['π', '∑', '∏', '∫', '√', '∞', '≠', '≤', '≥', '±', '×', '÷', '≈', '∂', 'Δ', '∇', '∈', '∝', '‰', '½', '¼', '¾', '⁰', '¹', '²', '³', '⁴', 'ⁿ'] },
  { name: 'Arrows', chars: ['→', '←', '↑', '↓', '↔', '↕', '⇒', '⇐', '⇔', '↗', '↘', '↳', '➜', '↺', '↻', '⇄'] },
  { name: 'Greek', chars: ['α', 'β', 'γ', 'δ', 'ε', 'ζ', 'η', 'θ', 'λ', 'μ', 'ν', 'ξ', 'ρ', 'σ', 'τ', 'φ', 'χ', 'ψ', 'ω', 'Γ', 'Δ', 'Θ', 'Λ', 'Σ', 'Φ', 'Ω'] },
];

export function SpecialCharsSheet({
  visible, onClose, onPick,
}: {
  visible: boolean;
  onClose: () => void;
  onPick: (ch: string) => void;
}) {
  const { colors } = useTheme();
  const [group, setGroup] = useState(0);
  return (
    <Sheet visible={visible} onClose={onClose} maxHeight={0.8}>
      <SheetHeader title="Special characters" onClose={onClose} />
      <View style={{ flexDirection: 'row', gap: 7, marginBottom: 14, flexWrap: 'wrap' }}>
        {CHAR_GROUPS.map((g, i) => (
          <Pressable key={g.name} onPress={() => setGroup(i)}
            style={[styles.tabChip, {
              backgroundColor: group === i ? colors.primarySoft : colors.surface,
              borderColor: group === i ? colors.primary : colors.border,
            }]}>
            <Text style={{ fontSize: 12.5, fontWeight: '700', color: group === i ? colors.primary : colors.subtext }}>{g.name}</Text>
          </Pressable>
        ))}
      </View>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        {CHAR_GROUPS[group].chars.map((ch, i) => (
          <Pressable
            key={i}
            onPress={() => { onPick(ch); haptic(); }}
            style={[styles.charCell, { backgroundColor: colors.surface, borderColor: colors.border }]}
          >
            <Text style={{ fontSize: 21, color: colors.text }}>{ch}</Text>
          </Pressable>
        ))}
      </View>
      <Text style={{ fontSize: 11.5, color: colors.faint, marginTop: 14, textAlign: 'center' }}>
        Tap a character to insert it at the cursor
      </Text>
    </Sheet>
  );
}

/* --------------------------------- equation -------------------------------- */

export function EquationEditor({
  visible, onClose, onSave, existing,
}: {
  visible: boolean;
  onClose: () => void;
  onSave: (expr: string) => void;
  existing?: EquationBlock | null;
}) {
  const { colors } = useTheme();
  const [expr, setExpr] = useState('');
  const wasVisible = useRef(false);

  if (visible && !wasVisible.current) {
    wasVisible.current = true;
    setExpr(existing?.expr || '');
  }
  if (!visible && wasVisible.current) wasVisible.current = false;

  const inputRef = useRef<TextInput>(null);

  return (
    <Sheet visible={visible} onClose={onClose} maxHeight={0.9}>
      <SheetHeader title={existing ? 'Edit equation' : 'Insert equation'} onClose={onClose}
        right={
          <Pressable onPress={() => { if (expr.trim()) { onSave(expr.trim()); onClose(); } }} disabled={!expr.trim()}
            style={[styles.primaryBtn, { backgroundColor: colors.primary, paddingVertical: 9, paddingHorizontal: 16, marginRight: 10, opacity: expr.trim() ? 1 : 0.4, marginTop: 0 }]}>
            <Text style={{ color: '#fff', fontWeight: '700', fontSize: 13.5 }}>{existing ? 'Update' : 'Insert'}</Text>
          </Pressable>
        } />

      {!!expr && (
        <View style={[styles.eqPreview, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={{ fontSize: 20, fontStyle: 'italic', fontFamily: 'serif', color: colors.text, textAlign: 'center' }}>
            {renderEquation(expr)}
          </Text>
        </View>
      )}

      <View style={[styles.field, { backgroundColor: colors.inputBg, borderColor: colors.border }]}>
        <TextInput
          ref={inputRef}
          value={expr}
          onChangeText={setExpr}
          placeholder="e.g. E = mc^{2} or \frac{a}{b}"
          placeholderTextColor={colors.faint}
          autoCapitalize="none"
          style={[styles.input, { color: colors.text, fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace' }]}
        />
      </View>

      <Text style={{ fontSize: 11.5, fontWeight: '800', color: colors.faint, letterSpacing: 1, marginBottom: 8 }}>SYMBOLS & STRUCTURES</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} keyboardShouldPersistTaps="always"
        contentContainerStyle={{ gap: 7, paddingBottom: 4 }}>
        {EQUATION_SNIPPETS.map((s, i) => (
          <Pressable key={i} onPress={() => { setExpr(e => e + s.insert); inputRef.current?.focus(); haptic(); }}
            style={[styles.eqChip, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={{ fontSize: 15, color: colors.text, fontFamily: 'serif' }}>{s.label}</Text>
          </Pressable>
        ))}
      </ScrollView>
      <Text style={{ fontSize: 11.5, color: colors.faint, marginTop: 12, lineHeight: 17 }}>
        Supports ^superscripts, _subscripts, \frac{'{a}{b}'}, \sqrt{'{x}'} and \greek letters.
      </Text>
    </Sheet>
  );
}

/* --------------------------------- dictate --------------------------------- */

export function DictateModal({
  visible, onClose, onInsert,
}: {
  visible: boolean;
  onClose: () => void;
  onInsert: (text: string) => void;
}) {
  const { colors } = useTheme();
  const [listening, setListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [typed, setTyped] = useState('');
  const pulse = useRef(new Animated.Value(1)).current;
  const recRef = useRef<any>(null);

  const g = globalThis as any;
  const SR = Platform.OS === 'web' ? (g.SpeechRecognition || g.webkitSpeechRecognition) : null;

  useEffect(() => {
    if (listening) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulse, { toValue: 1.25, duration: 650, useNativeDriver: true }),
          Animated.timing(pulse, { toValue: 1, duration: 650, useNativeDriver: true }),
        ])
      ).start();
    } else {
      pulse.setValue(1);
    }
  }, [listening, pulse]);

  const stop = () => {
    try { recRef.current?.stop(); } catch { /* noop */ }
    recRef.current = null;
    setListening(false);
  };

  const start = () => {
    if (!SR) return;
    const rec = new SR();
    rec.continuous = true;
    rec.interimResults = true;
    rec.lang = 'en-US';
    rec.onresult = (e: any) => {
      let text = '';
      for (let i = 0; i < e.results.length; i++) text += e.results[i][0].transcript;
      setTranscript(text);
    };
    rec.onerror = () => setListening(false);
    rec.onend = () => setListening(false);
    recRef.current = rec;
    setTranscript('');
    setListening(true);
    rec.start();
  };

  useEffect(() => () => { try { recRef.current?.stop(); } catch { /* noop */ } }, []);

  const close = () => { stop(); onClose(); };

  const content = SR ? transcript : typed;

  return (
    <Sheet visible={visible} onClose={close} maxHeight={0.85}>
      <SheetHeader title="Voice to text" onClose={close} />
      {SR ? (
        <View style={{ alignItems: 'center', paddingVertical: 8 }}>
          <Pressable onPress={() => { listening ? stop() : start(); haptic('medium'); }}>
            <Animated.View style={[styles.micBtn, {
              backgroundColor: listening ? colors.red : colors.primary,
              shadowColor: listening ? colors.red : colors.primary,
              transform: [{ scale: pulse }],
            }]}>
              <Ionicons name={listening ? 'stop' : 'mic'} size={30} color="#fff" />
            </Animated.View>
          </Pressable>
          <Text style={{ fontSize: 13.5, fontWeight: '700', color: colors.text, marginTop: 14 }}>
            {listening ? 'Listening… tap to stop' : 'Tap the mic and speak'}
          </Text>
          <Text style={{ fontSize: 11.5, color: colors.faint, marginTop: 3 }}>English (US) · on-device browser engine</Text>
          <View style={[styles.transcriptBox, { backgroundColor: colors.inputBg, borderColor: colors.border }]}>
            <ScrollView style={{ maxHeight: 120 }}>
              <Text style={{ fontSize: 14.5, color: transcript ? colors.text : colors.faint, lineHeight: 21 }}>
                {transcript || 'Your words will appear here…'}
              </Text>
            </ScrollView>
          </View>
        </View>
      ) : (
        <View>
          <Text style={{ fontSize: 13, color: colors.subtext, lineHeight: 19, marginBottom: 12 }}>
            On mobile, tap below and use the microphone on your keyboard to dictate — then insert the result.
          </Text>
          <View style={[styles.field, { backgroundColor: colors.inputBg, borderColor: colors.border, alignItems: 'flex-start' }]}>
            <TextInput
              value={typed}
              onChangeText={setTyped}
              placeholder="Dictate or type here…"
              placeholderTextColor={colors.faint}
              multiline
              autoFocus
              style={[styles.input, { color: colors.text, minHeight: 90, textAlignVertical: 'top' }]}
            />
          </View>
        </View>
      )}
      <Pressable
        onPress={() => { if (content.trim()) { onInsert(content.trim()); setTranscript(''); setTyped(''); close(); } }}
        disabled={!content.trim()}
        style={[styles.primaryBtn, { backgroundColor: colors.primary, opacity: content.trim() ? 1 : 0.4 }]}
      >
        <Ionicons name="arrow-down-circle" size={16} color="#fff" />
        <Text style={{ color: '#fff', fontWeight: '700', fontSize: 14.5 }}>Insert into note</Text>
      </Pressable>
    </Sheet>
  );
}

/* ---------------------------------- export --------------------------------- */

export function ExportSheet({
  visible, onClose, note, onDuplicate, onMessage,
}: {
  visible: boolean;
  onClose: () => void;
  note: Note;
  onDuplicate: () => void;
  onMessage: (msg: string) => void;
}) {
  const { colors } = useTheme();
  const [busy, setBusy] = useState<string | null>(null);

  const run = async (key: string, fn: () => Promise<string | void>) => {
    setBusy(key);
    try {
      const msg = await fn();
      onMessage(msg || 'Done');
      onClose();
    } catch (e) {
      onMessage('Something went wrong while exporting');
    } finally {
      setBusy(null);
    }
  };

  const RowItem = ({ k, icon, color, title, sub, fn }: {
    k: string; icon: keyof typeof Ionicons.glyphMap; color: string; title: string; sub: string; fn: () => Promise<string | void>;
  }) => (
    <Pressable onPress={() => run(k, fn)} style={[styles.exportRow, { borderColor: colors.border }]}>
      <View style={[styles.exportIcon, { backgroundColor: soft(color, 0.13) }]}>
        {busy === k
          ? <Ionicons name="sync" size={17} color={color} />
          : <Ionicons name={icon} size={17} color={color} />}
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 15, fontWeight: '700', color: colors.text }}>{title}</Text>
        <Text style={{ fontSize: 11.5, color: colors.faint, marginTop: 1 }}>{sub}</Text>
      </View>
      <Ionicons name="chevron-forward" size={16} color={colors.faint} />
    </Pressable>
  );

  return (
    <Sheet visible={visible} onClose={onClose} maxHeight={0.9}>
      <SheetHeader title="Share & export" onClose={onClose} />
      <ScrollView showsVerticalScrollIndicator={false}>
        <RowItem k="share" icon="share-social" color={colors.primary} title="Share"
          sub="Email, WhatsApp, Messages and more"
          fn={async () => { await shareNote(note); return 'Shared'; }} />
        <RowItem k="pdf" icon="document" color={colors.red} title="PDF document"
          sub="Print-ready, with your page setup applied"
          fn={() => exportNote(note, 'pdf')} />
        <RowItem k="doc" icon="logo-microsoft" color={colors.blue} title="Word document"
          sub="Opens in Word, Docs and Pages"
          fn={() => exportNote(note, 'doc')} />
        <RowItem k="txt" icon="reader" color={colors.green} title="Plain text"
          sub="Clean .txt without formatting"
          fn={() => exportNote(note, 'txt')} />
        <RowItem k="md" icon="code-slash" color={colors.yellow} title="Markdown"
          sub="For devs, blogs and wikis"
          fn={() => exportNote(note, 'md')} />
        <RowItem k="print" icon="print" color={colors.subtext} title="Print"
          sub="Send directly to a printer"
          fn={() => printNote(note)} />
        <Pressable
          onPress={() => { onDuplicate(); onMessage('Copy created'); onClose(); }}
          style={[styles.exportRow, { borderColor: colors.border }]}
        >
          <View style={[styles.exportIcon, { backgroundColor: colors.primarySoft }]}>
            <Ionicons name="copy" size={17} color={colors.primary} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 15, fontWeight: '700', color: colors.text }}>Make a copy</Text>
            <Text style={{ fontSize: 11.5, color: colors.faint, marginTop: 1 }}>Duplicate this note in the same notebook</Text>
          </View>
          <Ionicons name="chevron-forward" size={16} color={colors.faint} />
        </Pressable>
      </ScrollView>
    </Sheet>
  );
}

const styles = StyleSheet.create({
  field: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    borderRadius: 14, borderWidth: 1, paddingHorizontal: 13,
    paddingVertical: 11, marginBottom: 10,
  },
  input: { flex: 1, fontSize: 14.5, padding: 0, outlineStyle: 'none' } as object,
  primaryBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    paddingVertical: 13, borderRadius: 15, marginTop: 4,
  },
  tabChip: {
    paddingHorizontal: 13, paddingVertical: 7, borderRadius: 16, borderWidth: 1.5,
  },
  charCell: {
    width: 46, height: 46, borderRadius: 13, borderWidth: 1,
    alignItems: 'center', justifyContent: 'center',
  },
  eqPreview: {
    borderRadius: 15, borderWidth: 1, paddingVertical: 18, paddingHorizontal: 14, marginBottom: 12,
  },
  eqChip: {
    minWidth: 44, height: 44, borderRadius: 13, borderWidth: 1,
    alignItems: 'center', justifyContent: 'center', paddingHorizontal: 11,
  },
  micBtn: {
    width: 76, height: 76, borderRadius: 38,
    alignItems: 'center', justifyContent: 'center',
    shadowOpacity: 0.5, shadowRadius: 16, shadowOffset: { width: 0, height: 6 }, elevation: 8,
  },
  transcriptBox: {
    alignSelf: 'stretch', borderRadius: 15, borderWidth: 1,
    padding: 14, marginTop: 16, marginBottom: 6,
  },
  exportRow: {
    flexDirection: 'row', alignItems: 'center', gap: 13,
    paddingVertical: 12, borderBottomWidth: 1,
  },
  exportIcon: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
});
