import React, { useRef, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useTheme } from '../store/ThemeContext';
import { Chip, Sheet, SheetHeader } from '../components/ui';
import { ChartBlock, ChartDatum, ChartType } from '../types';
import { CHART_PALETTE } from '../theme';
import { ChartView } from '../components/ChartView';
import { haptic } from '../lib/storage';

export default function ChartEditor({
  visible, onClose, onSave, existing,
}: {
  visible: boolean;
  onClose: () => void;
  onSave: (data: Omit<ChartBlock, 'id'>) => void;
  existing?: ChartBlock | null;
}) {
  const { colors } = useTheme();
  const [type, setType] = useState<ChartType>('bar');
  const [title, setTitle] = useState('');
  const [data, setData] = useState<ChartDatum[]>([]);
  const wasVisible = useRef(false);

  if (visible && !wasVisible.current) {
    wasVisible.current = true;
    setType(existing?.chartType || 'bar');
    setTitle(existing?.title || '');
    setData(existing ? JSON.parse(JSON.stringify(existing.data)) : [
      { label: 'Jan', value: 12, color: CHART_PALETTE[0] },
      { label: 'Feb', value: 19, color: CHART_PALETTE[1] },
      { label: 'Mar', value: 8, color: CHART_PALETTE[2] },
    ]);
  }
  if (!visible && wasVisible.current) wasVisible.current = false;

  const setDatum = (i: number, patch: Partial<ChartDatum>) =>
    setData(prev => prev.map((d, di) => di === i ? { ...d, ...patch } : d));

  const addRow = () => {
    haptic();
    setData(prev => [...prev, { label: `Item ${prev.length + 1}`, value: 10, color: CHART_PALETTE[prev.length % CHART_PALETTE.length] }]);
  };

  const preview: ChartBlock = { id: 'preview', type: 'chart', chartType: type, title, data: data.filter(d => d.label.trim()) };

  return (
    <Sheet visible={visible} onClose={onClose} maxHeight={0.94}>
      <SheetHeader title={existing ? 'Edit chart' : 'Insert chart'} onClose={onClose}
        right={
          <Pressable
            onPress={() => { haptic('success'); onSave({ type: 'chart', chartType: type, title: title.trim(), data: data.filter(d => d.label.trim()) }); onClose(); }}
            style={[styles.done, { backgroundColor: colors.primary }]}
          >
            <Text style={{ color: '#fff', fontWeight: '700', fontSize: 13.5 }}>{existing ? 'Update' : 'Insert'}</Text>
          </Pressable>
        } />

      <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        <View style={{ flexDirection: 'row', gap: 8, marginBottom: 12 }}>
          <Chip label="Bar" icon="bar-chart" active={type === 'bar'} onPress={() => setType('bar')} />
          <Chip label="Line" icon="trending-up" active={type === 'line'} onPress={() => setType('line')} />
          <Chip label="Pie" icon="pie-chart" active={type === 'pie'} onPress={() => setType('pie')} />
        </View>

        <TextInput
          value={title}
          onChangeText={setTitle}
          placeholder="Chart title"
          placeholderTextColor={colors.faint}
          style={[styles.input, { backgroundColor: colors.inputBg, color: colors.text, borderColor: colors.border }]}
        />

        {preview.data.length > 0 && (
          <View style={[styles.preview, { borderColor: colors.border, backgroundColor: colors.card }]}>
            <ChartView block={preview} />
          </View>
        )}

        <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 6, marginBottom: 8 }}>
          <Text style={{ flex: 1, fontSize: 12, fontWeight: '800', color: colors.faint, letterSpacing: 1 }}>DATA</Text>
          <Pressable onPress={addRow} style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
            <Ionicons name="add-circle" size={16} color={colors.primary} />
            <Text style={{ fontSize: 13, fontWeight: '700', color: colors.primary }}>Add row</Text>
          </Pressable>
        </View>

        {data.map((d, i) => (
          <View key={i} style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 }}>
            <View style={{ width: 16, height: 16, borderRadius: 5, backgroundColor: d.color }} />
            <TextInput
              value={d.label}
              onChangeText={v => setDatum(i, { label: v })}
              placeholder="Label"
              placeholderTextColor={colors.faint}
              style={[styles.cellInput, { flex: 1.4, backgroundColor: colors.inputBg, color: colors.text, borderColor: colors.border }]}
            />
            <TextInput
              value={String(d.value)}
              onChangeText={v => setDatum(i, { value: parseFloat(v.replace(/[^0-9.\-]/g, '')) || 0 })}
              placeholder="0"
              placeholderTextColor={colors.faint}
              keyboardType="numeric"
              style={[styles.cellInput, { flex: 0.8, backgroundColor: colors.inputBg, color: colors.text, borderColor: colors.border }]}
            />
            <Pressable onPress={() => setDatum(i, { color: CHART_PALETTE[(CHART_PALETTE.indexOf(d.color) + 1) % CHART_PALETTE.length] })} hitSlop={6}>
              <Ionicons name="color-palette-outline" size={19} color={colors.subtext} />
            </Pressable>
            <Pressable onPress={() => setData(prev => prev.filter((_x, di) => di !== i))} hitSlop={6}>
              <Ionicons name="trash-outline" size={18} color={colors.red} />
            </Pressable>
          </View>
        ))}
        <View style={{ height: 10 }} />
      </ScrollView>
    </Sheet>
  );
}

const styles = StyleSheet.create({
  done: { paddingHorizontal: 16, paddingVertical: 9, borderRadius: 12, marginRight: 10 },
  input: {
    borderRadius: 13, paddingHorizontal: 14, paddingVertical: 11,
    fontSize: 14.5, borderWidth: 1, marginBottom: 10, outlineStyle: 'none',
  } as object,
  cellInput: {
    borderRadius: 11, paddingHorizontal: 12, paddingVertical: 9,
    fontSize: 13.5, borderWidth: 1, outlineStyle: 'none',
  } as object,
  preview: { borderRadius: 16, borderWidth: 1, padding: 10, marginBottom: 10 },
});
