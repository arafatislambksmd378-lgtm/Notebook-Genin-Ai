import React, { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useTheme } from '../store/ThemeContext';
import { BlockStyle, TextBlock } from '../types';
import { HIGHLIGHT_COLORS, TEXT_COLORS } from '../theme';
import { applyCase, CaseMode } from '../lib/utils';
import { haptic } from '../lib/storage';

export const STYLE_DEFAULT_SIZE: Record<BlockStyle, number> = {
  normal: 16, title: 30, h1: 26, h2: 22, h3: 19, h4: 17, h5: 15, h6: 13,
};

export const STYLE_LABELS: Record<BlockStyle, string> = {
  normal: 'Normal text', title: 'Title', h1: 'Heading 1', h2: 'Heading 2',
  h3: 'Heading 3', h4: 'Heading 4', h5: 'Heading 5', h6: 'Heading 6',
};

const STYLES: BlockStyle[] = ['normal', 'title', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'];

function TBtn({
  icon, label, glyph, glyphStyle, active, onPress, disabled,
}: {
  icon?: keyof typeof Ionicons.glyphMap;
  label?: string;
  glyph?: string;
  glyphStyle?: object;
  active?: boolean;
  onPress?: () => void;
  disabled?: boolean;
}) {
  const { colors } = useTheme();
  return (
    <Pressable
      onPress={() => { haptic(); onPress?.(); }}
      disabled={disabled}
      hitSlop={4}
      style={[styles.btn, {
        backgroundColor: active ? colors.primarySoft : 'transparent',
        opacity: disabled ? 0.35 : 1,
      }]}
    >
      {icon && <Ionicons name={icon} size={17.5} color={active ? colors.primary : colors.subtext} />}
      {!!glyph && (
        <Text style={[{ fontSize: 15, color: active ? colors.primary : colors.text }, glyphStyle]}>{glyph}</Text>
      )}
      {!!label && <Text style={{ fontSize: 13, fontWeight: '700', color: active ? colors.primary : colors.subtext }}>{label}</Text>}
    </Pressable>
  );
}

const Divider = () => {
  const { colors } = useTheme();
  return <View style={{ width: 1, height: 22, backgroundColor: colors.border, marginHorizontal: 4 }} />;
};

/** Mini alignment glyph built from bars - left / center / right */
export function AlignGlyph({ align, color }: { align: 'left' | 'center' | 'right'; color: string }) {
  return (
    <View style={{ width: 18, gap: 3, alignItems: align === 'left' ? 'flex-start' : align === 'center' ? 'center' : 'flex-end' }}>
      <View style={{ height: 2, width: 18, borderRadius: 1, backgroundColor: color }} />
      <View style={{ height: 2, width: 12, borderRadius: 1, backgroundColor: color }} />
      <View style={{ height: 2, width: 15, borderRadius: 1, backgroundColor: color }} />
    </View>
  );
}

export default function FormatToolbar({
  block, onPatch, visible,
}: {
  block: TextBlock | null;
  onPatch: (patch: Partial<TextBlock>) => void;
  visible: boolean;
}) {
  const { colors } = useTheme();
  const [panel, setPanel] = useState<'style' | 'color' | 'highlight' | null>(null);

  if (!visible) return null;
  const b = block;
  const curSize = b ? (b.fontSize || STYLE_DEFAULT_SIZE[b.style]) : 16;
  const noBlock = !b;

  const cycleAlign = () => {
    if (!b) return;
    const next = b.align === 'left' ? 'center' : b.align === 'center' ? 'right' : 'left';
    onPatch({ align: next });
  };

  const cycleCase = () => {
    if (!b || !b.text) return;
    const modes: CaseMode[] = ['upper', 'lower', 'title'];
    const upper = b.text === b.text.toUpperCase();
    const lower = b.text === b.text.toLowerCase();
    const mode = upper ? 'lower' : lower ? 'title' : 'upper';
    onPatch({ text: applyCase(b.text, mode) });
  };

  return (
    <View style={{ borderBottomWidth: 1, borderBottomColor: colors.border, backgroundColor: colors.card }}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} keyboardShouldPersistTaps="always"
        contentContainerStyle={{ alignItems: 'center', paddingHorizontal: 10, paddingVertical: 6, gap: 2 }}>
        <Pressable
          onPress={() => setPanel(p => p === 'style' ? null : 'style')}
          disabled={noBlock}
          style={[styles.styleChip, { backgroundColor: colors.surface, borderColor: panel === 'style' ? colors.primary : colors.border, opacity: noBlock ? 0.35 : 1 }]}
        >
          <Text style={{ fontSize: 12.5, fontWeight: '700', color: colors.text }}>
            {b ? STYLE_LABELS[b.style] : 'Style'}
          </Text>
          <Ionicons name="chevron-down" size={13} color={colors.subtext} />
        </Pressable>
        <Divider />
        <TBtn glyph="B" glyphStyle={{ fontWeight: '900' }} active={!!b?.bold} disabled={noBlock} onPress={() => onPatch({ bold: !b?.bold })} />
        <TBtn glyph="I" glyphStyle={{ fontStyle: 'italic', fontFamily: 'serif', fontWeight: '700' }} active={!!b?.italic} disabled={noBlock} onPress={() => onPatch({ italic: !b?.italic })} />
        <TBtn glyph="U" glyphStyle={{ fontWeight: '700', textDecorationLine: 'underline' }} active={!!b?.underline} disabled={noBlock} onPress={() => onPatch({ underline: !b?.underline })} />
        <TBtn glyph="S" glyphStyle={{ fontWeight: '700', textDecorationLine: 'line-through' }} active={!!b?.strike} disabled={noBlock} onPress={() => onPatch({ strike: !b?.strike })} />
        <Divider />
        <Pressable
          onPress={() => setPanel(p => p === 'color' ? null : 'color')}
          disabled={noBlock}
          style={[styles.btn, { opacity: noBlock ? 0.35 : 1 }]}
        >
          <View style={{ alignItems: 'center' }}>
            <Text style={{ fontSize: 15, fontWeight: '800', color: colors.text }}>A</Text>
            <View style={{ width: 18, height: 3.5, borderRadius: 2, backgroundColor: b?.color || colors.text }} />
          </View>
        </Pressable>
        <Pressable
          onPress={() => setPanel(p => p === 'highlight' ? null : 'highlight')}
          disabled={noBlock}
          style={[styles.btn, { opacity: noBlock ? 0.35 : 1 }]}
        >
          <View style={{ alignItems: 'center' }}>
            <Ionicons name="brush" size={15} color={colors.subtext} />
            <View style={{ width: 18, height: 3.5, borderRadius: 2, backgroundColor: b?.highlight || colors.border }} />
          </View>
        </Pressable>
        <Divider />
        <TBtn icon="remove" disabled={noBlock} onPress={() => onPatch({ fontSize: Math.max(10, curSize - 1) })} />
        <Text style={{ fontSize: 12.5, fontWeight: '800', color: colors.text, minWidth: 24, textAlign: 'center' }}>{curSize}</Text>
        <TBtn icon="add" disabled={noBlock} onPress={() => onPatch({ fontSize: Math.min(48, curSize + 1) })} />
        <Divider />
        <Pressable
          onPress={() => { haptic(); cycleAlign(); }}
          disabled={noBlock}
          hitSlop={4}
          style={[styles.btn, { opacity: noBlock ? 0.35 : 1 }]}
        >
          <AlignGlyph align={b?.align || 'left'} color={colors.subtext} />
        </Pressable>
        <TBtn icon="list" active={b?.list === 'bullet'} disabled={noBlock}
          onPress={() => onPatch({ list: b?.list === 'bullet' ? 'none' : 'bullet' })} />
        <TBtn icon="list-circle" active={b?.list === 'number'} disabled={noBlock}
          onPress={() => onPatch({ list: b?.list === 'number' ? 'none' : 'number' })} />
        <Divider />
        <TBtn icon="return-down-back" disabled={noBlock || !b?.indent}
          onPress={() => onPatch({ indent: Math.max(0, (b?.indent || 0) - 1) })} />
        <TBtn icon="return-down-forward" disabled={noBlock || (b?.indent || 0) >= 4}
          onPress={() => onPatch({ indent: Math.min(4, (b?.indent || 0) + 1) })} />
        <TBtn icon="arrow-up" label=" " active={!!b?.spaceBefore} disabled={noBlock} onPress={() => onPatch({ spaceBefore: !b?.spaceBefore })} />
        <TBtn icon="arrow-down" active={!!b?.spaceAfter} disabled={noBlock} onPress={() => onPatch({ spaceAfter: !b?.spaceAfter })} />
        <Divider />
        <TBtn icon="text" disabled={noBlock} onPress={cycleCase} />
        <TBtn icon="close-circle-outline" disabled={noBlock} onPress={() => onPatch({
          bold: false, italic: false, underline: false, strike: false,
          color: undefined, highlight: undefined, fontSize: undefined,
          style: 'normal', list: 'none', indent: 0, align: 'left',
          spaceBefore: false, spaceAfter: false,
        })} />
      </ScrollView>

      {panel === 'style' && (
        <View style={[styles.panel, { borderTopColor: colors.border }]}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} keyboardShouldPersistTaps="always"
            contentContainerStyle={{ gap: 8, paddingHorizontal: 4 }}>
            {STYLES.map(s => (
              <Pressable
                key={s}
                onPress={() => { onPatch({ style: s, fontSize: undefined }); setPanel(null); }}
                style={[styles.styleOpt, {
                  backgroundColor: b?.style === s ? colors.primarySoft : colors.surface,
                  borderColor: b?.style === s ? colors.primary : colors.border,
                }]}
              >
                <Text style={{
                  fontSize: Math.min(20, STYLE_DEFAULT_SIZE[s] * 0.72),
                  fontWeight: s === 'normal' ? '500' : '800',
                  color: b?.style === s ? colors.primary : colors.text,
                }}>
                  {s === 'normal' ? 'Aa' : s === 'title' ? 'Title' : `H${s.slice(1)}`}
                </Text>
                <Text style={{ fontSize: 9.5, color: colors.faint, fontWeight: '700', marginTop: 2 }}>{STYLE_LABELS[s]}</Text>
              </Pressable>
            ))}
          </ScrollView>
        </View>
      )}
      {panel === 'color' && (
        <View style={[styles.panel, { borderTopColor: colors.border }]}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            {TEXT_COLORS.map(c => (
              <Pressable key={c} onPress={() => { onPatch({ color: c }); setPanel(null); }}
                style={{ width: 30, height: 30, borderRadius: 15, backgroundColor: c, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: colors.border }}>
                {b?.color === c && <Ionicons name="checkmark" size={15} color="#fff" />}
              </Pressable>
            ))}
            <Pressable onPress={() => { onPatch({ color: undefined }); setPanel(null); }}
              style={{ width: 30, height: 30, borderRadius: 15, backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: colors.border }}>
              <Ionicons name="close" size={15} color={colors.subtext} />
            </Pressable>
          </View>
        </View>
      )}
      {panel === 'highlight' && (
        <View style={[styles.panel, { borderTopColor: colors.border }]}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            {HIGHLIGHT_COLORS.map(c => (
              <Pressable key={c} onPress={() => { onPatch({ highlight: c }); setPanel(null); }}
                style={{ width: 30, height: 30, borderRadius: 9, backgroundColor: c, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: colors.border }}>
                {b?.highlight === c && <Ionicons name="checkmark" size={15} color={colors.text} />}
              </Pressable>
            ))}
            <Pressable onPress={() => { onPatch({ highlight: undefined }); setPanel(null); }}
              style={{ width: 30, height: 30, borderRadius: 9, backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: colors.border }}>
              <Ionicons name="close" size={15} color={colors.subtext} />
            </Pressable>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  btn: {
    minWidth: 34, height: 34, borderRadius: 10, paddingHorizontal: 6,
    alignItems: 'center', justifyContent: 'center',
  },
  styleChip: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: 12, paddingVertical: 8, borderRadius: 12, borderWidth: 1.5,
    marginRight: 4,
  },
  panel: {
    paddingHorizontal: 14, paddingVertical: 12, borderTopWidth: 1,
  },
  styleOpt: {
    alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: 16, paddingVertical: 8, borderRadius: 14, borderWidth: 1.5,
    minWidth: 62,
  },
});
