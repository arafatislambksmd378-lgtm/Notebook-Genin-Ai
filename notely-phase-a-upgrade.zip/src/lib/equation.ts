const GREEK: Record<string, string> = {
  alpha: 'α', beta: 'β', gamma: 'γ', delta: 'δ', epsilon: 'ε',
  zeta: 'ζ', eta: 'η', theta: 'θ', iota: 'ι', kappa: 'κ',
  lambda: 'λ', mu: 'μ', nu: 'ν', xi: 'ξ', pi: 'π',
  rho: 'ρ', sigma: 'σ', tau: 'τ', upsilon: 'υ', phi: 'φ',
  chi: 'χ', psi: 'ψ', omega: 'ω',
  Gamma: 'Γ', Delta: 'Δ', Theta: 'Θ', Lambda: 'Λ', Xi: 'Ξ',
  Pi: 'Π', Sigma: 'Σ', Phi: 'Φ', Psi: 'Ψ', Omega: 'Ω',
  infty: '∞', partial: '∂', nabla: '∇', pm: '±', mp: '∓',
  times: '×', div: '÷', cdot: '·', neq: '≠', leq: '≤',
  geq: '≥', approx: '≈', equiv: '≡', propto: '∝',
  in: '∈', notin: '∉', subset: '⊂', supset: '⊃',
  cup: '∪', cap: '∩', forall: '∀', exists: '∃',
  int: '∫', iint: '∬', oint: '∮', sum: '∑', prod: '∏',
  rightarrow: '→', leftarrow: '←', Rightarrow: '⇒',
  Leftrightarrow: '⇔', mapsto: '↦', circ: '∘', deg: '°',
  perp: '⊥', parallel: '∥', angle: '∠', therefore: '∴',
  because: '∵', hbar: 'ℏ', ell: 'ℓ', Re: 'ℜ', Im: 'ℑ',
  aleph: 'ℵ', emptyset: '∅', land: '∧', lor: '∨', neg: '¬',
};

const SUP: Record<string, string> = {
  '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴',
  '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹',
  '+': '⁺', '-': '⁻', '=': '⁼', '(': '⁽', ')': '⁾',
  n: 'ⁿ', i: 'ⁱ', x: 'ˣ', y: 'ʸ', a: 'ᵃ', b: 'ᵇ',
  c: 'ᶜ', d: 'ᵈ', e: 'ᵉ', t: 'ᵗ',
};

const SUB: Record<string, string> = {
  '0': '₀', '1': '₁', '2': '₂', '3': '₃', '4': '₄',
  '5': '₅', '6': '₆', '7': '₇', '8': '₈', '9': '₉',
  '+': '₊', '-': '₋', '=': '₌', '(': '₍', ')': '₎',
  a: 'ₐ', e: 'ₑ', o: 'ₒ', x: 'ₓ', i: 'ᵢ', n: 'ₙ',
  k: 'ₖ', m: 'ₘ', p: 'ₚ', s: 'ₛ', t: 'ₜ',
};

const toSup = (s: string) => [...s].map(c => SUP[c] ?? c).join('');
const toSub = (s: string) => [...s].map(c => SUB[c] ?? c).join('');

/** Convert a light TeX-like syntax into beautiful unicode math text */
export function renderEquation(src: string): string {
  let s = src;
  s = s.replace(/\\frac\s*\{([^{}]*)\}\s*\{([^{}]*)\}/g, '($1)⁄($2)');
  s = s.replace(/\\sqrt\s*\{([^{}]*)\}/g, '√($1)');
  s = s.replace(/\\sqrt\s*(\w)/g, '√$1');
  s = s.replace(/\\([A-Za-z]+)/g, (m, name) => GREEK[name] ?? name);
  // superscripts (may repeat for nested pass)
  for (let i = 0; i < 2; i++) {
    s = s.replace(/\^\{([^{}]*)\}/g, (_m, g) => toSup(g));
    s = s.replace(/_\{([^{}]*)\}/g, (_m, g) => toSub(g));
  }
  s = s.replace(/\^(\w)/g, (_m, c) => SUP[c] ?? '^' + c);
  s = s.replace(/_(\w)/g, (_m, c) => SUB[c] ?? '_' + c);
  return s;
}

export const EQUATION_SNIPPETS: { label: string; insert: string }[] = [
  { label: 'x²', insert: '^{2}' },
  { label: 'xₙ', insert: '_{n}' },
  { label: 'a⁄b', insert: '\\frac{a}{b}' },
  { label: '√', insert: '\\sqrt{x}' },
  { label: '∑', insert: '\\sum_{i=1}^{n}' },
  { label: '∫', insert: '\\int_{a}^{b}' },
  { label: 'π', insert: '\\pi' },
  { label: 'θ', insert: '\\theta' },
  { label: 'Δ', insert: '\\Delta' },
  { label: 'λ', insert: '\\lambda' },
  { label: 'μ', insert: '\\mu' },
  { label: 'σ', insert: '\\sigma' },
  { label: 'φ', insert: '\\phi' },
  { label: 'Ω', insert: '\\Omega' },
  { label: '∞', insert: '\\infty' },
  { label: '≠', insert: '\\neq' },
  { label: '≤', insert: '\\leq' },
  { label: '≥', insert: '\\geq' },
  { label: '±', insert: '\\pm' },
  { label: '×', insert: '\\times' },
  { label: '÷', insert: '\\div' },
  { label: '→', insert: '\\rightarrow' },
  { label: '∂', insert: '\\partial' },
  { label: '°', insert: '\\deg' },
];

export const EQUATION_SAMPLES = [
  'E = mc^{2}',
  '\\int_{a}^{b} f(x) dx = F(b) - F(a)',
  'x = \\frac{-b \\pm \\sqrt{b^{2} - 4ac}}{2a}',
  'e^{i\\pi} + 1 = 0',
  '\\sum_{i=1}^{n} i = \\frac{n(n+1)}{2}',
];
