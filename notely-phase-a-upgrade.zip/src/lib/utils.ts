import { Block, Note, TextBlock } from '../types';

export const uid = (): string =>
  Date.now().toString(36) + Math.random().toString(36).slice(2, 9);

export const clamp = (v: number, min: number, max: number) =>
  Math.max(min, Math.min(max, v));

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export function formatDate(ts: number): string {
  const d = new Date(ts);
  const now = new Date();
  const sameDay = d.toDateString() === now.toDateString();
  const yest = new Date(now.getTime() - 86400000);
  if (sameDay) {
    const h = d.getHours();
    const m = d.getMinutes().toString().padStart(2, '0');
    const ampm = h >= 12 ? 'PM' : 'AM';
    return `Today, ${((h + 11) % 12) + 1}:${m} ${ampm}`;
  }
  if (d.toDateString() === yest.toDateString()) return 'Yesterday';
  if (d.getFullYear() === now.getFullYear()) return `${MONTHS[d.getMonth()]} ${d.getDate()}`;
  return `${MONTHS[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`;
}

export function formatFullDate(ts: number): string {
  const d = new Date(ts);
  return `${DAYS[d.getDay()]}, ${MONTHS[d.getMonth()]} ${d.getDate()}`;
}

export function formatDateTime(ts: number): string {
  const d = new Date(ts);
  const h = d.getHours();
  const m = d.getMinutes().toString().padStart(2, '0');
  const ampm = h >= 12 ? 'PM' : 'AM';
  return `${MONTHS[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()} · ${((h + 11) % 12) + 1}:${m} ${ampm}`;
}

export function greeting(): string {
  const h = new Date().getHours();
  if (h < 5) return 'Working late';
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  if (h < 21) return 'Good evening';
  return 'Good night';
}

export interface WordStats {
  words: number;
  chars: number;
  charsNoSpaces: number;
  pages: number;
  readingMin: number;
}

export function blockPlainText(b: Block): string {
  switch (b.type) {
    case 'text': return b.text;
    case 'equation': return b.expr;
    case 'table': return b.rows.map(r => r.join(' ')).join(' ');
    case 'chart': return b.title + ' ' + b.data.map(d => d.label).join(' ');
    default: return '';
  }
}

export function wordStats(blocks: Block[], wordsPerPage = 275): WordStats {
  const text = blocks.map(blockPlainText).join(' ');
  const words = (text.match(/\S+/g) || []).length;
  const chars = text.replace(/\n/g, ' ').length;
  const charsNoSpaces = text.replace(/\s/g, '').length;
  return {
    words,
    chars,
    charsNoSpaces,
    pages: Math.max(1, Math.ceil(words / wordsPerPage)),
    readingMin: Math.max(1, Math.round(words / 200)),
  };
}

export type CaseMode = 'upper' | 'lower' | 'title';

export function applyCase(text: string, mode: CaseMode): string {
  if (mode === 'upper') return text.toUpperCase();
  if (mode === 'lower') return text.toLowerCase();
  return text.replace(/\w\S*/g, w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase());
}

export function noteSnippet(note: Note, maxLen = 140): string {
  const parts: string[] = [];
  const title = note.title.trim().toLowerCase();
  for (const b of note.blocks) {
    if (b.type === 'text' && b.text.trim()) {
      const t = b.text.trim();
      if (title && t.toLowerCase() === title) continue;
      parts.push(t);
    }
    if (parts.join(' ').length > maxLen) break;
  }
  const s = parts.join(' ');
  return s.length > maxLen ? s.slice(0, maxLen).trimEnd() + '…' : s;
}

export function firstImage(note: Note): string | null {
  for (const b of note.blocks) if (b.type === 'image') return b.uri;
  return null;
}

export function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export function tocEntries(blocks: Block[]): { id: string; text: string; level: number }[] {
  const out: { id: string; text: string; level: number }[] = [];
  for (const b of blocks) {
    if (b.type !== 'text' || !b.text.trim()) continue;
    const t = b as TextBlock;
    if (t.style === 'title') out.push({ id: t.id, text: t.text, level: 0 });
    else if (/^h[1-6]$/.test(t.style)) out.push({ id: t.id, text: t.text, level: parseInt(t.style[1], 10) });
  }
  return out;
}
