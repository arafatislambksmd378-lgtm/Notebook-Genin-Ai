import { DrawPath, DrawPoint } from '../types';

const f = (n: number) => Math.round(n * 100) / 100;

/** Smooth polyline through points using quadratic mid-point technique */
export function smoothLine(points: DrawPoint[]): string {
  if (points.length === 0) return '';
  if (points.length === 1) {
    const p = points[0];
    return `M ${f(p.x)} ${f(p.y)} L ${f(p.x + 0.02)} ${f(p.y + 0.02)}`;
  }
  if (points.length === 2) {
    return `M ${f(points[0].x)} ${f(points[0].y)} L ${f(points[1].x)} ${f(points[1].y)}`;
  }
  let d = `M ${f(points[0].x)} ${f(points[0].y)}`;
  for (let i = 1; i < points.length - 1; i++) {
    const mx = (points[i].x + points[i + 1].x) / 2;
    const my = (points[i].y + points[i + 1].y) / 2;
    d += ` Q ${f(points[i].x)} ${f(points[i].y)} ${f(mx)} ${f(my)}`;
  }
  const last = points[points.length - 1];
  d += ` L ${f(last.x)} ${f(last.y)}`;
  return d;
}

/**
 * Calligraphy nib stroke: builds a filled polygon whose width varies with
 * stroke direction relative to a fixed nib angle - the classic italic-pen look.
 */
export function calligraphyPath(points: DrawPoint[], baseWidth: number, nibAngleDeg = -42): string {
  if (points.length === 0) return '';
  if (points.length < 3) {
    const p = points[0];
    const r = Math.max(1, baseWidth * 0.32);
    return `M ${f(p.x - r)} ${f(p.y)} A ${f(r)} ${f(r)} 0 1 1 ${f(p.x + r)} ${f(p.y)} A ${f(r)} ${f(r)} 0 1 1 ${f(p.x - r)} ${f(p.y)} Z`;
  }
  const phi = (nibAngleDeg * Math.PI) / 180;
  const left: DrawPoint[] = [];
  const right: DrawPoint[] = [];
  for (let i = 0; i < points.length; i++) {
    const p = points[i];
    const a = points[Math.max(0, i - 1)];
    const b = points[Math.min(points.length - 1, i + 1)];
    let dx = b.x - a.x;
    let dy = b.y - a.y;
    const len = Math.hypot(dx, dy) || 1;
    dx /= len; dy /= len;
    const theta = Math.atan2(dy, dx);
    const w = (baseWidth / 2) * (0.22 + 0.78 * Math.abs(Math.cos(theta - phi)));
    left.push({ x: p.x - dy * w, y: p.y + dx * w });
    right.push({ x: p.x + dy * w, y: p.y - dx * w });
  }
  let d = `M ${f(left[0].x)} ${f(left[0].y)}`;
  for (let i = 1; i < left.length; i++) d += ` L ${f(left[i].x)} ${f(left[i].y)}`;
  for (let i = right.length - 1; i >= 0; i--) d += ` L ${f(right[i].x)} ${f(right[i].y)}`;
  return d + ' Z';
}

/** Exponential smoothing used by stroke stabilization */
export function stabilizePoint(prev: DrawPoint, raw: DrawPoint, amount: number): DrawPoint {
  return {
    x: prev.x * amount + raw.x * (1 - amount),
    y: prev.y * amount + raw.y * (1 - amount),
  };
}

/** Distance from point p to segment ab */
function segDist(p: DrawPoint, a: DrawPoint, b: DrawPoint): number {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const l2 = dx * dx + dy * dy;
  if (l2 === 0) return Math.hypot(p.x - a.x, p.y - a.y);
  let t = ((p.x - a.x) * dx + (p.y - a.y) * dy) / l2;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(p.x - (a.x + t * dx), p.y - (a.y + t * dy));
}

export function pathHit(path: DrawPath, p: DrawPoint, tol: number): boolean {
  const pts = path.points;
  const threshold = tol + path.width / 2;
  for (let i = 0; i < pts.length - 1; i++) {
    if (segDist(p, pts[i], pts[i + 1]) < threshold) return true;
  }
  if (pts.length === 1) return Math.hypot(p.x - pts[0].x, p.y - pts[0].y) < threshold;
  return false;
}
